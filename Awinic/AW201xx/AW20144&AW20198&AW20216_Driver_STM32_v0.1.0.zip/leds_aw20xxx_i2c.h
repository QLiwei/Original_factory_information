#ifndef __LEDS_AW20XXX_I2C_H__
#define __LEDS_AW20XXX_I2C_H__
 
#include "string.h"
#include "stm32h7xx_hal.h"
#include "stm32h7xx_hal_i2c.h"
#include "aw_type.h"
#include "aw_lamp_interface.h"
#include "leds_aw20xxx_reg.h"

/* Declare I2C handle Structure definition */
extern I2C_HandleTypeDef hi2c1;

/* Configuring MCU GPIO */
#define AW20XXX_GPIO			GPIOA
#define AW20XXX_GPIO_EN			GPIO_PIN_3

/* EN_GPIO PA3 */
#ifndef REST_GPIO
#define GPIO_EN_HIGH()			((AW20XXX_GPIO->BSRR)= AW20XXX_GPIO_EN)
#define GPIO_EN_LOW()			((AW20XXX_GPIO->BSRR) = \
										(unsigned int)AW20XXX_GPIO_EN << (16U))
#endif

#define AW20144_CHIP_ENABLE		(1)
#define AW20198_CHIP_ENABLE		(0)
#define AW20216_CHIP_ENABLE		(0)

#define AW20XXX_MAX_CURRENT		(0x9f)
#define AW20XXX_RSL_SET			(0xff) /* R colour brightness set */
#define AW20XXX_GSL_SET			(0xb9) /* G colour brightness set  */
#define AW20XXX_BSL_SET			(0xef) /* B colour brightness set*/

#define AW20XXX_MAX_PWM			(0xff)
#define AW20XXX_MAX_BREATH_PWM	(0xff) /* auto breath pwm */
#define AW20XXX_MIN_BREATH_PWM	(0x00) /* R colour brightness set */

/*********************************************************
 *
 * pag num
 *
 ***********************************)*********************/
#define AW20144_REG_NUM_PAG1	(144)
#define AW20144_REG_NUM_PAG2	(144)
#define AW20144_REG_NUM_PAG3	(48)
#define AW20144_REG_NUM_PAG4	(144)

#define AW20198_REG_NUM_PAG1	(198)
#define AW20198_REG_NUM_PAG2	(198)
#define AW20198_REG_NUM_PAG3	(66)
#define AW20198_REG_NUM_PAG4	(198)

#define AW20216_REG_NUM_PAG1	(216)
#define AW20216_REG_NUM_PAG2	(216)
#define AW20216_REG_NUM_PAG3	(72)
#define AW20216_REG_NUM_PAG4	(216)

#if AW20144_CHIP_ENABLE
#define AW20XXX_REG_NUM_PAG1	AW20144_REG_NUM_PAG1
#define AW20XXX_REG_NUM_PAG2	AW20144_REG_NUM_PAG2
#define AW20XXX_REG_NUM_PAG3	AW20144_REG_NUM_PAG3
#define AW20XXX_REG_NUM_PAG4	AW20144_REG_NUM_PAG4
#elif AW20198_CHIP_ENABLE
#define AW20XXX_REG_NUM_PAG1	AW20198_REG_NUM_PAG1
#define AW20XXX_REG_NUM_PAG2	AW20198_REG_NUM_PAG2
#define AW20XXX_REG_NUM_PAG3	AW20198_REG_NUM_PAG3
#define AW20XXX_REG_NUM_PAG4	AW20198_REG_NUM_PAG4
#elif AW20216_CHIP_ENABLE
#define AW20XXX_REG_NUM_PAG1	AW20216_REG_NUM_PAG1
#define AW20XXX_REG_NUM_PAG2	AW20216_REG_NUM_PAG2
#define AW20XXX_REG_NUM_PAG3	AW20216_REG_NUM_PAG3
#define AW20XXX_REG_NUM_PAG4	AW20216_REG_NUM_PAG4
#endif

/*********************************************************
 *
 * chip info
 *
 ********************************************************/
#define AW20XXX_DEVICE_ADDR		(0X20 << 1) /* AD0 and AD1 both LOW */

#define AW20144_CHIPID			(0x74)
#define AW20198_CHIPID			(0x71)
#define AW20216_CHIPID			(0x70)
#if AW20144_CHIP_ENABLE
#define AW20XXX_CHIPID			AW20144_CHIPID
#elif AW20198_CHIP_ENABLE
#define AW20XXX_CHIPID			AW20198_CHIPID
#elif AW20216_CHIP_ENABLE
#define AW20XXX_CHIPID			AW20216_CHIPID
#endif

#define AW20XXX_PAGE_ADDR		(0xF0)
#define AW20XXX_CMD_PAGE0		(0xC0)
#define AW20XXX_CMD_PAGE1		(0xC1)
#define AW20XXX_CMD_PAGE2		(0xC2)
#define AW20XXX_CMD_PAGE3		(0xC3)
#define AW20XXX_CMD_PAGE4		(0xC4)

#if AW20144_CHIP_ENABLE
#define LED_NUM					(144)
#elif AW20198_CHIP_ENABLE
#define LED_NUM					(198)
#elif AW20216_CHIP_ENABLE
#define LED_NUM					(216)
#endif

#define RGB_NUM					(LED_NUM / 3)

#define BIT_CHIPEN_DIS			(~(1<<0))
#define BIT_CHIPEN_EN			(0x1)
#define BIT_SHORT_EN			(0x5)
#define BIT_OPEN_EN				(0x7)

enum AW20XXX_T0_T2_TIME {
	T0T20_00S = 0x00,
	T0T20_13S = 0X10,
	T0T20_26S = 0X20,
	T0T20_38S = 0x30,
	T0T20_51S = 0X40,
	T0T20_77S = 0X50,
	T0T21_04S = 0x60,
	T0T21_60S = 0X70,
	T0T22_10S = 0X80,
	T0T22_60S = 0X90,
	T0T23_10S = 0XA0,
	T0T24_20S = 0XB0,
	T0T25_20S = 0XC0,
	T0T26_20S = 0XD0,
	T0T27_30S = 0XE0,
	T0T28_30S = 0XF0
};

enum AW20XXX_T1_T3_TIME {
	T1T30_04S = 0x00,
	T1T30_13S = 0X01,
	T1T30_26S = 0X02,
	T1T30_38S = 0x03,
	T1T30_51S = 0X04,
	T1T30_77S = 0X05,
	T1T31_04S = 0x06,
	T1T31_60S = 0X07,
	T1T32_10S = 0X08,
	T1T32_60S = 0X09,
	T1T33_10S = 0X0A,
	T1T34_20S = 0X0B,
	T1T35_20S = 0X0C,
	T1T36_20S = 0X0D,
	T1T37_30S = 0X0E,
	T1T38_30S = 0X0F
};

/* I2c status */
#define I2C_RETRY_TIMES				(0x5)
typedef enum {
	AW_I2C_OK = 0x0,
	AW_I2C_ERROR = 0x1,
	AW_I2C_BUSY = 0x2,
	AW_I2C_TIMEOUT = 0x3
} AW_I2C_StatusTypeDef;

/*********************************************************
 *
 * algorithm variable
 *
 ********************************************************/
static unsigned char aw20xxx_page1_data[AW20XXX_REG_NUM_PAG1] = {0};
static unsigned char aw20xxx_page2_data[AW20XXX_REG_NUM_PAG2] = {0};
static AW_U16 aw20xxx_page4_data[AW20XXX_REG_NUM_PAG4] = {0};
static unsigned char dim_data[LED_NUM];
static unsigned char fade_data[LED_NUM];
static AW_COLORFUL_INTERFACE_STRUCT aw20xxx_interface;
static ALGO_DATA_STRUCT algo_data;

static unsigned char loop_end[RGB_NUM] = {0};
static AW_COLOR_STRUCT source_color[RGB_NUM];
static AW_COLOR_STRUCT destination_color[RGB_NUM];
static ALGO_DATA_STRUCT aw20xxx_algo_data[RGB_NUM];
static unsigned char breath_phase_nums[RGB_NUM] = {0};
static unsigned char breath_cur_phase[RGB_NUM] = {0};
static unsigned char breath_cur_loop[RGB_NUM] = {0};
static unsigned char colorful_cur_color_index[RGB_NUM] = {0};

extern void aw20xxx_play(void);

#define AWINIC_UART_DEBUG
#ifdef AWINIC_UART_DEBUG
#define AWINIC_I2C_NAME "awinic_log"
#define AWLOG(format, arg...)	printf("[%s] %s %d: " format, AWINIC_I2C_NAME,\
		__func__, __LINE__, ##arg)
#else
#define AWLOG(format, arg...)
#endif

#endif
