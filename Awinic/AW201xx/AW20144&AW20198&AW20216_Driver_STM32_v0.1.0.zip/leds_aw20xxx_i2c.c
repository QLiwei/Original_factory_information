#include "leds_aw20xxx_i2c.h"
#include "gpio.h"
#include "leds_effect_data.c"

#define AW20XXX_DRIVER_VERSION		"v0.1.0"

/* This is just a rough delay */
static void delay_ms(AW_U32 ms)
{
	AW_U32 i = 0;

	while (ms--) {
		for (i = 0; i < 200000; i++);
		__NOP;
	}
}

static AW_U8 aw_i2c_writebyte(AW_U8 regaddr, AW_U8 regdata)
{
	AW_U8 res = 0;
	AW_U8 cnt = 0;

	while (cnt < I2C_RETRY_TIMES) {
		res = HAL_I2C_Mem_Write(&hi2c1, AW20XXX_DEVICE_ADDR, regaddr,
				I2C_MEMADD_SIZE_8BIT, &regdata, 1, 100);
		if (res != AW_I2C_OK)
			AWLOG("i2c_write cnt = %d, error = %d\n", cnt, res);
		else
			break;

		cnt++;
	}

	return res;
}

static AW_U8 aw_i2c_readbyte(AW_U8 regaddr, AW_U8 *regdata)
{
	AW_U8 res = 0;
	AW_U8 cnt = 0;

	while (cnt < I2C_RETRY_TIMES) {
		res = HAL_I2C_Mem_Read(&hi2c1, AW20XXX_DEVICE_ADDR, regaddr,
				I2C_MEMADD_SIZE_8BIT, regdata, 1, 100);
		if (res != AW_I2C_OK)
			AWLOG("i2c_read cnt = %d, error = %d\n", cnt, res);
		else
			break;

		cnt++;
	}

	return res;
}

static AW_U8 aw_i2c_write_buf(AW_U8 regaddr, AW_U16 *regdata,
		AW_U16 nums)
{
	AW_U8 res = 0;
	AW_U8 cnt = 0;

	while (cnt < I2C_RETRY_TIMES) {
		res = HAL_I2C_Mem_Write(&hi2c1, AW20XXX_DEVICE_ADDR, regaddr,
				I2C_MEMADD_SIZE_8BIT, (AW_U8 *)regdata, nums * 2, 100);
		if (res != AW_I2C_OK)
			AWLOG("i2c_write cnt = %d, error = %d\n", cnt, res);
		else
			break;

		cnt++;
	}

	return res;
}

static void aw20xxx_chip_hwen(void)
{
	GPIO_EN_HIGH();
	/* delay 2ms at least */
	delay_ms(2);
}

static void aw20xxx_soft_rst(void)
{
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE0);
	aw_i2c_writebyte(REG_RSTN, 0xAE);
	/* delay 2ms at least */
	delay_ms(3);
};

static void aw20xxx_chip_swen(void)
{
	AW_U8 val = 0;

	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE0);
	aw_i2c_readbyte(REG_GCR, &val);
	val &= BIT_CHIPEN_DIS;
	val |= BIT_CHIPEN_EN;
	aw_i2c_writebyte(REG_GCR, val);
}

static AW_BOOL aw20xxx_chip_id(void)
{
	AW_U8 val = 0;
	AW_BOOL id_sta = AW_FALSE;

	aw_i2c_readbyte(REG_RSTN, &val);
	if(AW20XXX_CHIPID == val){
		AWLOG("chip id 0x%x\n", val);
		id_sta = AW_TRUE;
	}

	return id_sta;
}

static void aw20xxx_set_global_current(AW_U8 current)
{
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE0);
	aw_i2c_writebyte(REG_GCCR, current);
}

static void aw20xxx_set_breath_pwm(AW_U8 pwm_reg, AW_U8 pwm)
{
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE0);
	aw_i2c_writebyte(pwm_reg, pwm);
}

static void aw20xxx_set_constant_current_by_idx(AW_U8 idx,
		AW_U8 constant_current)
{
	aw_i2c_writebyte(idx, constant_current);
}

static void aw20xxx_set_pwm_by_idx(int idx, unsigned char pwm)
{
	aw_i2c_writebyte(idx, pwm);
}

static void aw20xxx_fast_clear_display(void)
{
	int i = 0;

	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE1);
	for(i = 0;i < AW20XXX_REG_NUM_PAG1; i++){
		aw20xxx_set_pwm_by_idx(i, 0x00);
	}

	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE2);
	for(i = 0;i < AW20XXX_REG_NUM_PAG2; i++){
		aw20xxx_set_constant_current_by_idx(i, 0x00);
	}
}

static void aw20xxx_RGB_brightness_or_colour(void)
{
	AW_U16 i = 0;

	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE2);
	for (i = 0; i < AW20XXX_REG_NUM_PAG1 / 3; i++) {
		/* R colour brightness set*/
		aw20xxx_set_constant_current_by_idx(i * 3, AW20XXX_RSL_SET);
		/* G colour brightness set*/
		aw20xxx_set_constant_current_by_idx(i * 3 + 1, AW20XXX_GSL_SET);
		/* B colour brightness set*/
		aw20xxx_set_constant_current_by_idx(i * 3 + 2, AW20XXX_BSL_SET);
	}
}

static void aw20xxx_fast_breath_PWM_display(void)
{
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE0);
	/* 2. set pattern0_breath max/min level */
	aw20xxx_set_breath_pwm(REG_PWMH0, AW20XXX_MAX_BREATH_PWM);
	aw20xxx_set_breath_pwm(REG_PWML0, AW20XXX_MIN_BREATH_PWM);
	aw20xxx_set_breath_pwm(REG_PWMH1, AW20XXX_MAX_BREATH_PWM);
	aw20xxx_set_breath_pwm(REG_PWML1, AW20XXX_MIN_BREATH_PWM);
	aw20xxx_set_breath_pwm(REG_PWMH2, AW20XXX_MAX_BREATH_PWM);
	aw20xxx_set_breath_pwm(REG_PWML2, AW20XXX_MIN_BREATH_PWM);
}

static int aw20xxx_init(void)
{
	int ret = 0;
	AW_U8 val;

	/* 1. enable hwen gpio */
	aw20xxx_chip_hwen();

	aw20xxx_soft_rst();

	/* 2. enable chipen and set 0x00 0xb1 number */
	aw20xxx_chip_swen();
	//aw_i2c_writebyte(AW20XXX_CMD_PAGE0, REG_GCR, 0xb1);//0x00 0xb1

	/* 3. check chip id reg (0x2f) */
	ret = aw20xxx_chip_id();

	/* 4. config global current 0x01 0xff*/
	aw20xxx_set_global_current(0xff);//

	/* 5. enable page4 0x46 0x04*/
	aw_i2c_writebyte(REG_MIXCR, 0x04);

	return ret;
}

static void aw20xxx_all_on(void)
{
	int i = 0;

	/* 1.set constant current for broghtness */
	aw20xxx_RGB_brightness_or_colour();

	/* 2.set PWM for brigstness */
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE1);
	for (i = 0; i < AW20XXX_REG_NUM_PAG2; i++) {
		aw20xxx_set_pwm_by_idx(i, AW20XXX_MAX_PWM);
	}
}

static void aw20xxx_all_breath_forever(void)
{
	int i = 0;

	/* 1. set breath pwm mode source pattern controller 0*/
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE3);
	for (i = 0; i < AW20XXX_REG_NUM_PAG3; i++) {
		aw_i2c_writebyte(i, 0x15);
	}

	/* 2. set RGB current for brightness Equal to set color */
	aw20xxx_RGB_brightness_or_colour();

	/* 3. pattern controller init */
	aw20xxx_fast_breath_PWM_display();

	/* 4. set pattern 0-2 breath T0, T1, T2, T3 */
	aw_i2c_writebyte(REG_PAT0T0, T0T23_10S | T1T30_38S);
	aw_i2c_writebyte(REG_PAT0T1, T0T23_10S | T1T30_04S);

	aw_i2c_writebyte(REG_PAT1T0, T0T23_10S | T1T30_38S);
	aw_i2c_writebyte(REG_PAT1T1, T0T23_10S | T1T30_04S);

	aw_i2c_writebyte(REG_PAT2T0, T0T23_10S | T1T30_38S);
	aw_i2c_writebyte(REG_PAT2T1, T0T23_10S | T1T30_04S);

	/* 5. set pattern 0-2 breath start form xx state */
	aw_i2c_writebyte(REG_PAT0T2, 0x00);

	aw_i2c_writebyte(REG_PAT1T2, 0x00);

	aw_i2c_writebyte(REG_PAT2T2, 0x00);

	/* 6. set pattern 0-2 breath loop times -> forever */
	aw_i2c_writebyte(REG_PAT0T3, 0x00);

	aw_i2c_writebyte(REG_PAT1T3, 0x00);

	aw_i2c_writebyte(REG_PAT2T3, 0x00);

	/* 7. set pattern 0-2 breath mode */
	aw_i2c_writebyte(REG_PAT0CFG, 0x03);

	aw_i2c_writebyte(REG_PAT1CFG, 0x03);

	aw_i2c_writebyte(REG_PAT2CFG, 0x03);

	/* 8. start breath */
	aw_i2c_writebyte(REG_PATGO, 0x07);
}

static void aw20xxx_all_manual(void)
{
	int i = 0;

	/* 1. set breath pwm mode source pattern controller 0*/
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE3);
	for(i = 0; i < AW20XXX_REG_NUM_PAG3; i++){
		aw_i2c_writebyte(i, 0x15);
	}

	/* 2. set RGB current for brightness Equal to set color */
	aw20xxx_RGB_brightness_or_colour();

	/* 3. pattern controller init */
	aw20xxx_fast_breath_PWM_display();

	/* 4. set pattern 0-2 breath T0, T1, T2, T3 */
	aw_i2c_writebyte(REG_PAT0T0, T0T23_10S | T1T30_38S);
	aw_i2c_writebyte(REG_PAT0T1, T0T23_10S | T1T30_04S);

	aw_i2c_writebyte(REG_PAT1T0, T0T23_10S | T1T30_38S);
	aw_i2c_writebyte(REG_PAT1T1, T0T23_10S | T1T30_04S);

	aw_i2c_writebyte(REG_PAT2T0, T0T23_10S | T1T30_38S);
	aw_i2c_writebyte(REG_PAT2T1, T0T23_10S | T1T30_04S);

	/* 5. set pattern 0-2 breath start form xx state */
	aw_i2c_writebyte(REG_PAT0T2, 0x00);

	aw_i2c_writebyte(REG_PAT1T2, 0x00);

	aw_i2c_writebyte(REG_PAT2T2, 0x00);

	/* 6. set pattern 0-2 breath loop times -> forever */
	aw_i2c_writebyte(REG_PAT0T3, 0x00);

	aw_i2c_writebyte(REG_PAT1T3, 0x00);

	aw_i2c_writebyte(REG_PAT2T3, 0x00);

	/* 7. set auto_breath mode */
	aw_i2c_writebyte(REG_PAT0CFG, 0x0d);
	aw_i2c_writebyte(REG_PAT1CFG, 0x0d);
	aw_i2c_writebyte(REG_PAT2CFG, 0x0d);
}

/* **************************************************************
Only when there is current flowing through the LED, the detection
of open leakage and short circuit can be carried out. Therefore,
it is necessary to light up the LED first and then detect the open
leakage and short circuit.
*****************************************************************/
static void aw20xxx_open_detect(AW_U8 *data)
{
	AW_U8 val = 0;
	AW_U8 i,j = 0;

	/* 1. enable chipen and set SW number and enable open detect */
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE0);
	aw_i2c_readbyte(REG_GCR, &val);
	val &= BIT_CHIPEN_DIS;
	val |= BIT_OPEN_EN;
	aw_i2c_writebyte(REG_GCR, val);

	for (i = 0; i < AW20XXX_REG_NUM_PAG3 / 2; i++) {
		aw_i2c_readbyte(REG_OSR0 + i, &val); /* 0x03-0x26 */
		for (j = 0; j < 6; j++) {
			*(data + 6*i + j) = val & 0x01;
			val  = val >> 1;
		}
	}
}

static void aw20xxx_short_detect(AW_U8 *data)
{
	AW_U8 val = 0;
	AW_U8 i,j = 0;

	/* 1. enable chipen and set SW number and enable open detect */
	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE0);
	aw_i2c_readbyte(REG_GCR, &val);
	val &= BIT_CHIPEN_DIS;
	val |= BIT_SHORT_EN;
	AWLOG("val 0x%x\n", val);
	aw_i2c_writebyte(REG_GCR, val);

	for (i = 0; i < AW20XXX_REG_NUM_PAG3 / 2; i++) {
		aw_i2c_readbyte(REG_OSR0 + i, &val); /* 0x03-0x26 */
		for (j = 0;j < 6; j++) {
			*(data + 6*i + j) = val & 0x01;
			val  = val >> 1;
		}
	}
}

/*********************************************************
 *
 * light effect
 *
 ********************************************************/
void aw20xxx_rgb_multi_breath_init(const AW_MULTI_BREATH_DATA_STRUCT *data)
{
	unsigned char i;
	aw20xxx_interface.getBrightnessfunc =
			aw_get_breath_brightness_algo_func(BREATH_ALGO_GAMMA_CORRECTION);
	algo_data.cur_frame = 0;
	algo_data.total_frames = 20;
	algo_data.data_start = 0;
	algo_data.data_end = 0;
	aw20xxx_interface.p_algo_data = &algo_data;

	for(i = 0; i < RGB_NUM; i++) {
		colorful_cur_color_index[i] = 0;
		breath_cur_phase[i] = 0;
		breath_phase_nums[i] = 5;
		aw20xxx_algo_data[i].cur_frame = 0;
		aw20xxx_algo_data[i].total_frames = data[i].time[0] / 20;
		aw20xxx_algo_data[i].data_start = data[i].fadel;
		aw20xxx_algo_data[i].data_end = data[i].fadeh;
		source_color[i].r = 0x00;
		source_color[i].g = 0x00;
		source_color[i].b = 0x00;
		destination_color[i].r = 0x00;
		destination_color[i].g = 0x00;
		destination_color[i].b = 0x00;
	}
}

void aw20xxx_update_frame_idx(const AW_MULTI_BREATH_DATA_STRUCT *data)
{
	unsigned char i;
	int update_frame_idx = 0;

	for(i = 0;i < RGB_NUM; i++){
		if(loop_end[i] == 1){
				continue;
		}
		update_frame_idx = 1;

		source_color[i].r = destination_color[i].r;
		source_color[i].g = destination_color[i].g;
		source_color[i].b = destination_color[i].b;

		aw20xxx_algo_data[i].cur_frame ++;
		if (aw20xxx_algo_data[i].cur_frame >=
				aw20xxx_algo_data[i].total_frames) {
			aw20xxx_algo_data[i].cur_frame = 0;
			breath_cur_phase[i]++;
			if (breath_cur_phase[i] >= breath_phase_nums[i]) {
				colorful_cur_color_index[i]++;
				breath_cur_phase[i] = 1;
				if (colorful_cur_color_index[i] >= data[i].color_nums) {
					colorful_cur_color_index[i] = 0;
					if (0 == data[i].repeat_nums) {
						//breath_cur_loop[i] = 0;
					} else if (breath_cur_loop[i] >=
							(data[i].repeat_nums - 1)) {
						breath_cur_loop[i] = 0;
						update_frame_idx = 0;
					} else {
						breath_cur_loop[i] ++;
					}
				}
			}
		}

		destination_color[i].r =
				data[i].rgb_color_list[colorful_cur_color_index[i]].r;
		destination_color[i].g =
				data[i].rgb_color_list[colorful_cur_color_index[i]].g;
		destination_color[i].b =
				data[i].rgb_color_list[colorful_cur_color_index[i]].b;
		if ( update_frame_idx ) {
				aw20xxx_algo_data[i].total_frames =
					(data[i].time[breath_cur_phase[i]]) / 20;
				if (breath_cur_phase[i] == 1) {
					aw20xxx_algo_data[i].data_start = data[i].fadel;
					aw20xxx_algo_data[i].data_end = data[i].fadeh;
				} else if (breath_cur_phase[i] == 2) {
					aw20xxx_algo_data[i].data_start = data[i].fadeh;
					aw20xxx_algo_data[i].data_end = data[i].fadeh;
				} else if (breath_cur_phase[i] == 3) {
					aw20xxx_algo_data[i].data_start = data[i].fadeh;
					aw20xxx_algo_data[i].data_end = data[i].fadel;
				} else {
					aw20xxx_algo_data[i].data_start = data[i].fadel;
					aw20xxx_algo_data[i].data_end = data[i].fadel;
				}
			} else {
				loop_end[i] = 1;
			}
	}
}

void aw20xxx_frame_display(void)
{
	unsigned char i;
	unsigned char brightness = 0;

	for (i = 0; i < RGB_NUM; i++) {
		aw20xxx_interface.p_color_1 = &source_color[i];
		aw20xxx_interface.p_color_2 = &destination_color[i];
		aw_set_colorful_rgb_data(i, dim_data, &aw20xxx_interface);
		brightness = aw20xxx_interface.getBrightnessfunc(&aw20xxx_algo_data[i]);
		aw_set_rgb_brightness(i, fade_data, brightness);
	}
}

void aw20xxx_update(void)
{
	unsigned char i;

	for (i = 0; i < RGB_NUM; i++) {
		aw20xxx_page4_data[aw20xxx_reg_map[i*3 + 0]] =
				(fade_data[i*3 + 0] << 8) | dim_data[i*3 + 0];
		aw20xxx_page4_data[aw20xxx_reg_map[i*3 + 1]] =
				(fade_data[i*3 + 1] << 8) | dim_data[i*3 + 1];
		aw20xxx_page4_data[aw20xxx_reg_map[i*3 + 2]] =
				(fade_data[i*3 + 2] << 8) | dim_data[i*3 + 2];
	}

	aw_i2c_writebyte(AW20XXX_PAGE_ADDR, AW20XXX_CMD_PAGE4);
	aw_i2c_write_buf(0x00, aw20xxx_page4_data, AW20XXX_REG_NUM_PAG4);
}

void aw20xxx_rgb_multi_breath(const AW_MULTI_BREATH_DATA_STRUCT *data)
{
	aw20xxx_rgb_multi_breath_init(data);

	aw20xxx_frame_display();

	aw20xxx_update();

	while(1)
	{
		delay_ms(1);
		aw20xxx_update_frame_idx(data);
		aw20xxx_frame_display();
		aw20xxx_update();
	}
}

/*********************************************************
 *
 * call interface
 *
*********************************************************/
void aw20xxx_play(void)
{
	int ret = 0;
#if AW20144_CHIP_ENABLE
	AW_U8 data_buf[144] = {0}; /* aw20144 */
#elif AW20198_CHIP_ENABLE
	AW_U8 data_buf[198] = {0}; /* aw20198 */
#elif AW20216_CHIP_ENABLE
	AW_U8 data_buf[216] = {0}; /* aw20216 */
#endif

	ret = aw20xxx_init();
	if (ret == 0) {
		AWLOG("aw20xxx init failed\n");
		return;
	}

	//aw20xxx_all_on();
	//aw20xxx_all_breath_forever();
	//aw20xxx_all_manual();
	//aw20xxx_open_detect(data_buf);
	//aw20xxx_short_detect(data_buf);
	//delay_ms(5);
	aw20xxx_rgb_multi_breath(aw20xxx_rgb72_data);
}

