#include "leds_aw20xxx_i2c.h"
#include "aw_lamp_interface.h"

/*********************************************************
 *
 * reg map
 *
 ********************************************************/
static const int aw20xxx_reg_map[] = {
/* PWM,  SL,*/
#if AW20144_CHIP_ENABLE
	//rgb0
	0x00,0x01,0x02,
	//rgb1
	0x12,0x13,0x14,
	//rgb2
	0x24,0x25,0x26,
	//rgb3
	0x36,0x37,0x38,
	//rgb4
	0x48,0x49,0x4a,
	//rgb5
	0x5a,0x5b,0x5c,
	//rgb6
	0x6c,0x6d,0x6e,
	//rgb7
	0x7e,0x7f,0x80,

	//rgb8
	0x03,0x04,0x05,
	//rgb9
	0x15,0x16,0x17,
	//rgb10
	0x27,0x28,0x29,
	//rgb11
	0x39,0x3a,0x3b,
	//rgb12
	0x4b,0x4c,0x4d,
	//rgb13
	0x5d,0x5e,0x5f,
	//rgb14
	0x6f,0x70,0x71,
	//rgb15
	0x81,0x82,0x83,

	//rgb16
	0x06,0x07,0x08,
	//rgb17
	0x18,0x19,0x1a,
	//rgb18
	0x2a,0x2b,0x2c,
	//rgb19
	0x3c,0x3d,0x3e,
	//rgb20
	0x4e,0x4f,0x50,
	//rgb21
	0x60,0x61,0x62,
	//rgb22
	0x72,0x73,0x74,
	//rgb23
	0x84,0x85,0x86,

	//rgb24
	0x09,0x0a,0x0b,
	//rgb25
	0x1b,0x1c,0x1d,
	//rgb26
	0x2d,0x2e,0x2f,
	//rgb27
	0x3f,0x40,0x41,
	//rgb28
	0x51,0x52,0x53,
	//rgb29
	0x63,0x64,0x65,
	//rgb30
	0x75,0x76,0x77,
	//rgb31
	0x87,0x88,0x89,

	//rgb32
	0x0c,0x0d,0x0e,
	//rgb33
	0x1e,0x1f,0x20,
	//rgb34
	0x30,0x31,0x32,
	//rgb35
	0x42,0x43,0x44,
	//rgb36
	0x54,0x55,0x56,
	//rgb37
	0x66,0x67,0x68,
	//rgb38
	0x78,0x79,0x7a,
	//rgb39
	0x8a,0x8b,0x8c,

	//rgb40
	0x0f,0x10,0x11,
	//rgb41
	0x21,0x22,0x23,
	//rgb42
	0x33,0x34,0x35,
	//rgb43
	0x45,0x46,0x47,
	//rgb44
	0x57,0x58,0x59,
	//rgb45
	0x69,0x6a,0x6b,
	//rgb46
	0x7b,0x7c,0x7d,
	//rgb47
	0x8d,0x8e,0x8f,
#endif
#if AW20198_CHIP_ENABLE
	//rgb0
	0x00,0x01,0x02,
	//rgb1
	0x12,0x13,0x14,
	//rgb2
	0x24,0x25,0x26,
	//rgb3
	0x36,0x37,0x38,
	//rgb4
	0x48,0x49,0x4a,
	//rgb5
	0x5a,0x5b,0x5c,
	//rgb6
	0x6c,0x6d,0x6e,
	//rgb7
	0x7e,0x7f,0x80,
	//rgb8
	0x90,0x91,0x92,
	//rgb9
	0xa2,0xa3,0xa4,
	//rgb10
	0xb4,0xb5,0xb6,

	//rgb11
	0x03,0x04,0x05,
	//rgb12
	0x15,0x16,0x17,
	//rgb13
	0x27,0x28,0x29,
	//rgb14
	0x39,0x3a,0x3b,
	//rgb15
	0x4b,0x4c,0x4d,
	//rgb16
	0x5d,0x5e,0x5f,
	//rgb17
	0x6f,0x70,0x71,
	//rgb18
	0x81,0x82,0x83,
	//rgb19
	0x93,0x94,0x95,
	//rgb20
	0xa5,0xa6,0xa7,
	//rgb21
	0xb7,0xb8,0xb9,

	//rgb22
	0x06,0x07,0x08,
	//rgb23
	0x18,0x19,0x1a,
	//rgb24
	0x2a,0x2b,0x2c,
	//rgb25
	0x3c,0x3d,0x3e,
	//rgb26
	0x4e,0x4f,0x50,
	//rgb27
	0x60,0x61,0x62,
	//rgb28
	0x72,0x73,0x74,
	//rgb29
	0x84,0x85,0x86,
	//rgb30
	0x96,0x97,0x98,
	//rgb31
	0xa8,0xa9,0xaa,
	//rgb32
	0xba,0xbb,0xbc,

	//rgb33
	0x09,0x0a,0x0b,
	//rgb34
	0x1b,0x1c,0x1d,
	//rgb35
	0x2d,0x2e,0x2f,
	//rgb36
	0x3f,0x40,0x41,
	//rgb37
	0x51,0x52,0x53,
	//rgb38
	0x63,0x64,0x65,
	//rgb39
	0x75,0x76,0x77,
	//rgb40
	0x87,0x88,0x89,
	//rgb41
	0x99,0x9a,0x9b,
	//rgb42
	0xab,0xac,0xad,
	//rgb43
	0xbd,0xbe,0xbf,

	//rgb44
	0x0c,0x0d,0x0e,
	//rgb45
	0x1e,0x1f,0x20,
	//rgb46
	0x30,0x31,0x32,
	//rgb47
	0x42,0x43,0x44,
	//rgb48
	0x54,0x55,0x56,
	//rgb49
	0x66,0x67,0x68,
	//rgb50
	0x78,0x79,0x7a,
	//rgb51
	0x8a,0x8b,0x8c,
	//rgb52
	0x9c,0x9d,0x9e,
	//rgb53
	0xae,0xaf,0xb0,
	//rgb54
	0xc0,0xc1,0xc2,

	//rgb55
	0x0f,0x10,0x11,
	//rgb56
	0x21,0x22,0x23,
	//rgb57
	0x33,0x34,0x35,
	//rgb58
	0x45,0x46,0x47,
	//rgb59
	0x57,0x58,0x59,
	//rgb60
	0x69,0x6a,0x6b,
	//rgb61
	0x7b,0x7c,0x7d,
	//rgb62
	0x8d,0x8e,0x8f,
	//rgb63
	0x9f,0xa0,0xa1,
	//rgb64
	0xb1,0xb2,0xb3,
	//rgb65
	0xc3,0xc4,0xc5,
#endif	
#if AW20216_CHIP_ENABLE
	//rgb0
	0x00,0x01,0x02,
	//rgb1
	0x12,0x13,0x14,
	//rgb2
	0x24,0x25,0x26,
	//rgb3
	0x36,0x37,0x38,
	//rgb4
	0x48,0x49,0x4a,
	//rgb5
	0x5a,0x5b,0x5c,
	//rgb6
	0x6c,0x6d,0x6e,
	//rgb7
	0x7e,0x7f,0x80,
	//rgb8
	0x90,0x91,0x92,
	//rgb9
	0xa2,0xa3,0xa4,
	//rgb10
	0xb4,0xb5,0xb6,
	//rgb11
	0xc6,0xc7,0xc8,

	//rgb12
	0x03,0x04,0x05,
	//rgb13
	0x15,0x16,0x17,
	//rgb14
	0x27,0x28,0x29,
	//rgb15
	0x39,0x3a,0x3b,
	//rgb16
	0x4b,0x4c,0x4d,
	//rgb17
	0x5d,0x5e,0x5f,
	//rgb18
	0x6f,0x70,0x71,
	//rgb19
	0x81,0x82,0x83,
	//rgb20
	0x93,0x94,0x95,
	//rgb21
	0xa5,0xa6,0xa7,
	//rgb22
	0xb7,0xb8,0xb9,
	//rgb23
	0xc9,0xca,0xcb,

	//rgb24
	0x06,0x07,0x08,
	//rgb25
	0x18,0x19,0x1a,
	//rgb26
	0x2a,0x2b,0x2c,
	//rgb27
	0x3c,0x3d,0x3e,
	//rgb28
	0x4e,0x4f,0x50,
	//rgb29
	0x60,0x61,0x62,
	//rgb30
	0x72,0x73,0x74,
	//rgb31
	0x84,0x85,0x86,
	//rgb32
	0x96,0x97,0x98,
	//rgb33
	0xa8,0xa9,0xaa,
	//rgb34
	0xba,0xbb,0xbc,
	//rgb35
	0xcc,0xcd,0xce,

	//rgb36
	0x09,0x0a,0x0b,
	//rgb37
	0x1b,0x1c,0x1d,
	//rgb38
	0x2d,0x2e,0x2f,
	//rgb39
	0x3f,0x40,0x41,
	//rgb40
	0x51,0x52,0x53,
	//rgb41
	0x63,0x64,0x65,
	//rgb42
	0x75,0x76,0x77,
	//rgb43
	0x87,0x88,0x89,
	//rgb44
	0x99,0x9a,0x9b,
	//rgb45
	0xab,0xac,0xad,
	//rgb46
	0xbd,0xbe,0xbf,
	//rgb47
	0xcf,0xd0,0xd1,

	//rgb48
	0x0c,0x0d,0x0e,
	//rgb49
	0x1e,0x1f,0x20,
	//rgb50
	0x30,0x31,0x32,
	//rgb51
	0x42,0x43,0x44,
	//rgb52
	0x54,0x55,0x56,
	//rgb53
	0x66,0x67,0x68,
	//rgb54
	0x78,0x79,0x7a,
	//rgb55
	0x8a,0x8b,0x8c,
	//rgb56
	0x9c,0x9d,0x9e,
	//rgb57
	0xae,0xaf,0xb0,
	//rgb58
	0xc0,0xc1,0xc2,
	//rgb59
	0xd2,0xd3,0xd4,

	//rgb60
	0x0f,0x10,0x11,
	//rgb61
	0x21,0x22,0x23,
	//rgb62
	0x33,0x34,0x35,
	//rgb63
	0x45,0x46,0x47,
	//rgb64
	0x57,0x58,0x59,
	//rgb65
	0x69,0x6a,0x6b,
	//rgb66
	0x7b,0x7c,0x7d,
	//rgb67
	0x8d,0x8e,0x8f,
	//rgb68
	0x9f,0xa0,0xa1,
	//rgb69
	0xb1,0xb2,0xb3,
	//rgb70
	0xc3,0xc4,0xc5,
	//rgb71
	0xd5,0xd6,0xd7,
#endif
};

/*********************************************************
 *
 * effect data
 *
 ********************************************************/
#if 1 //rainbow ring
static const AW_COLOR_STRUCT rgb_color_list0[] = {
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
};

static const AW_COLOR_STRUCT rgb_color_list1[] = {
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list2[] = {
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list3[] = {
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list4[] = {
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list5[] = {
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list6[] = {
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list7[] = {
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list8[] = {
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list9[] = {
	{130,255 ,0 ,},
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list10[] = {
	{100,255 ,0 ,},
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
};

static const AW_COLOR_STRUCT rgb_color_list11[] = {
	{70,255,0 ,},
	{30,255 ,0 ,},
	{30,230 ,0 ,},
	{30,180 ,0 ,},
	{20,120 ,0 ,},
	{20,120 ,10 ,},
	{0,120 ,15 ,},
	{0,100 ,70 ,},
	{0,75 ,80 ,},
	{0,50 ,100 ,},
	{0,0 ,150 ,},
	{0,0 ,200 ,},
	{30,0 ,255 ,},
	{50,0 ,255 ,},
	{70,0 ,255 ,},
	{100,0 ,255 ,},
	{150,0 ,220 ,},
	{170,0 ,200 ,},
	{170,0 ,160,},
	{210,0 ,160 ,},
	{210,0 ,160 ,},
	{210,0 ,100 ,},
	{210,0 ,50 ,},
	{255,0 ,50 ,},
	{255,0 ,25 ,},
	{255,0 ,0 ,},
	{255,15 ,0 ,},
	{255,30,0 ,},
	{255,80 ,0 ,},
	{255,180 ,0 ,},
	{255,255 ,0 ,},
	{200,200 ,0 ,},
	{150,200,0 ,},
	{130,200 ,0 ,},
	{130,255 ,0 ,},
	{100,255 ,0 ,},
};

static const AW_MULTI_BREATH_DATA_STRUCT aw20xxx_rgb72_data[] = {
#if AW20144_CHIP_ENABLE
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
#endif

#if AW20198_CHIP_ENABLE
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
#endif

#if AW20216_CHIP_ENABLE
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list11)/sizeof(AW_COLOR_STRUCT),rgb_color_list11},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list11)/sizeof(AW_COLOR_STRUCT),rgb_color_list11},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list11)/sizeof(AW_COLOR_STRUCT),rgb_color_list11},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list11)/sizeof(AW_COLOR_STRUCT),rgb_color_list11},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list11)/sizeof(AW_COLOR_STRUCT),rgb_color_list11},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list0)/sizeof(AW_COLOR_STRUCT),rgb_color_list0},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list1)/sizeof(AW_COLOR_STRUCT),rgb_color_list1},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list2)/sizeof(AW_COLOR_STRUCT),rgb_color_list2},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list3)/sizeof(AW_COLOR_STRUCT),rgb_color_list3},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list4)/sizeof(AW_COLOR_STRUCT),rgb_color_list4},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list5)/sizeof(AW_COLOR_STRUCT),rgb_color_list5},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list6)/sizeof(AW_COLOR_STRUCT),rgb_color_list6},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list7)/sizeof(AW_COLOR_STRUCT),rgb_color_list7},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list8)/sizeof(AW_COLOR_STRUCT),rgb_color_list8},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list9)/sizeof(AW_COLOR_STRUCT),rgb_color_list9},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list10)/sizeof(AW_COLOR_STRUCT),rgb_color_list10},
	{{0,20,0,30,0},0,255,255,sizeof(rgb_color_list11)/sizeof(AW_COLOR_STRUCT),rgb_color_list11},
#endif
};
#endif

#if 0 /* breath */
static const AW_COLOR_STRUCT rgb_color_list[] = {
	{  0,  0,255},
	{  0,255,  0},
	{255,  0,  0},
	{255,190,139},
};

static const AW_MULTI_BREATH_DATA_STRUCT aw20xxx_rgb72_data[] = {
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{0,4000,1000,5000,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
};
#endif

#if 0 /*horse race lamp */
static const AW_COLOR_STRUCT rgb_color_list[] = {
	{255,  0,  0},
	{  0,255,  0},
	{  0,  0,255},
	{127,127,127},
};

static const AW_MULTI_BREATH_DATA_STRUCT aw20xxx_rgb72_data[] = {
#if AW20144_CHIP_ENABLE
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
#endif

#if AW20198_CHIP_ENABLE
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
#endif

#if AW20216_CHIP_ENABLE
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 440,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 440,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 440,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 440,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 440,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{   0,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  40,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{  80,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 120,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 160,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 200,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 240,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 280,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 320,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 360,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 400,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
	{{ 440,300,200,260,0},0,255,0,sizeof(rgb_color_list)/sizeof(AW_COLOR_STRUCT),rgb_color_list},
#endif
};

#endif
