//#include "headfile.h"
// Standard C Included Files
#include "fsl_spi_dma.h"
#include "fsl_dmamux.h"
#include "board.h"
#include "fsl_debug_console.h"

#include "pin_mux.h"
//#include "clock_config.h"
#include "fsl_common.h"
#include "fsl_port.h"
#include "pin_mux.h"
#include "fsl_gpio.h"
#include "head_dma.h"

#include "ExtSpiFlash.h"
#include "seeed_lcd.h"



#define EFLASH_PAGE_SIZE	256

#define NAND_FLASH_PAGE_SIZE		(2048+128)
#define NAND_FLASH_CACHE_SIZE		(2048)

#define NAND_FLASH_BLOCKNUM			(1024)
#define NAND_FLASH_BLOCK_PAGENUM	(64)


#define Flash_CS  0

#define FLASH_CS_L			GPIO_ClearPinsOutput(GPIOB, 1U << Flash_CS) 
#define FLASH_CS_H			GPIO_SetPinsOutput(GPIOB, 1U << Flash_CS)


#define MASTER_TRANSFER_TIMEOUT1     (5000U)             /*! Transfer timeout of master - 5s */


#define SPI_FLASH_BUSY		0x01

#define E_JEDEC		0x9f
#define E_RDSR		0x05
#define E_WREN		0x06
#define E_WRDI		0x04
#define E_ULBPR		0x98
#define E_CE			0xc7
#define E_SE			0x20
#define E_BE			0xd8
#define E_PP			0x02
#define E_READ		0x03
#define E_DPD		0xb9
#define E_RDPD		0xab


#define NAND_WRITEENABLE						0x06	/* spi nand write enable */
#define NAND_WRITEDISABLE						0x04	/* spi nand write disable */
#define NAND_READID							0x9f	/* read spi nand id */
#define NAND_GLOBALBLOCKUNLOCK				0x98	/* spi global block unlock */
#define NAND_PAGEREADTOCATCH					0x13	/* read page data to spi nand cache */
#define NAND_READFROMCATCH                			0x03    	/* read from spi nand cache */
#define NAND_PROGRAMLOAD						0X02    	/* program load random data */
#define NAND_PROGRAMLOAD_X4					0X32    	/* program load random data x4*/
#define NAND_PROGRAMEXECUTE					0x10    	/* program load execute */
#define NAND_PROGRAMLOADRANDOMDATA 		0X84    	/* program load random data */
#define NAND_PROGRAMLOADRANDOMDATA_X4        0Xc4    	/* program load random data x4*/

#define NAND_BLOCKERASE						0xd8	/* erase spi nand block 128K */		

#define SPINAND_CMD_GET_FEATURE 		0x0f    	/* get spi nand feature */
#define SPINAND_CMD_SET_FEATURE 		0x1f    	/* set spi nand feature */

#define SPINAND_ADDR_STATUS     		0xc0    	/* get feature status addr */
#define SPINAND_ADDR_FEATURE    		0xb0	/* set feature addr */
#define SPINAND_ADDR_Block_Lock     		0xa0    	/* get feature Block_Lock addr */

#define E_FALI          (1 << 2)        		/* erase fail */
#define P_FAIL          (1 << 3)        		/* write fail */
#define SPINAND_IS_BUSY (1 << 0)	/* PROGRAM EXECUTE, PAGE READ, BLOCK ERASE, or RESET command is executing */
#define SPINAND_WRITE_EN (1 << 1)	/* Write enable */

//#define NAND_GETREGS

void u_Delay(int l)
{
	while(l--); 
}
static void delay(uint32_t mtime)
{
	uint32_t i = 0;
	uint32_t j = 0;
	
	for(i=0; i<mtime; i++)
	{
		for(j=0; j<1000; j++)
		{
			__asm("nop");
		}
	}

}

void Select_Flash_CS(void)
{
	FLASH_CS_L;
}

void Release_Flash_CS(void)
{
	FLASH_CS_H;
}

/**********************************************
//
//д�����

**********************************************/

#define MASTER_TRANSFER_TIMEOUT0     (5000U)             /*! Transfer timeout of master - 5s */

void SPI_Write(uint8_t data)
{
	spi_transfer_t xfer = {0};
	uint8_t *pdata;
	pdata=&data;
	xfer.txData = pdata;
	xfer.rxData = NULL;
	xfer.dataSize = 1;
	master1Finished = false;
	SPI_MasterTransferDMA(SPI1, &master1Handle, &xfer);
	while (master1Finished != true)
	{
		// waiting until the buff1 full, and ready to be send to SPI LCD.
	}
}


/**********************************************
//
//�������

**********************************************/
#if 0
uint8_t SPI_Read(uint8_t *data, uint32_t len)
{
	spi_transfer_t xfer = {0};
	xfer.txData = NULL;
	xfer.rxData = data;
	xfer.dataSize = len;
	master1Finished = false;
	SPI_MasterTransferDMA(SPI1, &master1Handle, &xfer);
	while (master1Finished != true)
	{
		// waiting until the buff1 full, and ready to be send to SPI LCD.
	}	
	return 1;
}

uint8_t DMA_SPI_Read(uint8_t *data, uint32_t len)
{
	spi_transfer_t xfer = {0};
	xfer.txData = NULL;
	xfer.rxData = data;
	xfer.dataSize = len;
	master1Finished = false;
	SPI_MasterTransferDMA(SPI1, &master1Handle, &xfer);
	return 1;
}

void DMA_SpiFlash_Read_WaitFor_Finish(void)
{
	while (master1Finished != true)
	{
		// waiting until the buff1 full, and ready to be send to SPI LCD.
	}	
	Release_Flash_CS(); 
	Power_Suspend();
}

void DMA_Clean_SpiFlash_Read_WaitFor_Finish(void)
{
	while (master1Finished != true)
	{
		// waiting until the buff1 full, and ready to be send to SPI LCD.
		if(NeedFillData)
		{
			//PRINTF("----------------------------------Time BG \r\n");
			Dma_GetFlashData();
		}
	}	
}
#else
uint8_t SPI_Read(uint8_t *data, uint32_t len)
{
	spi_transfer_t xfer = {0};
	xfer.txData = NULL;
	xfer.rxData = data;
	xfer.dataSize = len;
	master1Finished = false;
	SPI_MasterTransferDMA(SPI1, &master1Handle, &xfer);

	if(!dma_spiflash_read)
	{
		while (master1Finished != true)
		{
			// waiting until the buff1 full, and ready to be send to SPI LCD.
		}	
	}
	return 1;
}

void DMA_SpiFlash_Read_WaitFor_Finish(void)
{
	while (master1Finished != true)
	{
		// waiting until the buff1 full, and ready to be send to SPI LCD.
	}	
	dma_spiflash_read = false;
}

void DMA_Clean_SpiFlash_Read_WaitFor_Finish(void)
{
	while (master1Finished != true)
	{
		// waiting until the buff1 full, and ready to be send to SPI LCD.
		if(NeedFillData)
		{
			//PRINTF("----------------------------------Time BG \r\n");
			Dma_GetFlashData();
		}
	}	
}
#endif
void Power_Suspend(void)
{
#if 0
	Select_Flash_CS();
	SPI_Write(E_DPD);
	Release_Flash_CS();	
#endif
}    

void Power_Resume(void)
{
#if 0
	Select_Flash_CS();
	SPI_Write(E_RDPD);
	Release_Flash_CS();	
#endif
}    

#if 0
void WriteEnable(void)
{
	Select_Flash_CS();
	SPI_Write(E_WREN);
	Release_Flash_CS();	
}
#else
void WriteEnable(void)
{
	uint8_t status;
	uint32_t ECount=0;

	Select_Flash_CS();
	SPI_Write(NAND_WRITEENABLE);
	Release_Flash_CS();	
	
	do
	{
		Select_Flash_CS();
		SPI_Write(SPINAND_CMD_GET_FEATURE);
		SPI_Write(SPINAND_ADDR_STATUS);
		SPI_Read(&status,1);
		ECount++;
		Release_Flash_CS();	
	}while((!(status & SPINAND_WRITE_EN)) && (ECount<MASTER_TRANSFER_TIMEOUT0));
	//PRINTF("WriteEnable \r\n");
}
#endif

#if 0
void WriteDisable(void)
{
	Select_Flash_CS();
	SPI_Write(E_WRDI);
	Release_Flash_CS();	
}
#else
void WriteDisable(void)
{
	Select_Flash_CS();
	SPI_Write(NAND_WRITEDISABLE);
	Release_Flash_CS();	
}
#endif

void GetFeatures(uint8_t register_add)
{
	uint8_t FLASH_Status;
	uint32_t ECount=0;
	
	Select_Flash_CS();
	SPI_Write(SPINAND_CMD_GET_FEATURE);
	SPI_Write(register_add);
	SPI_Read(&FLASH_Status,1);
	Release_Flash_CS();	
	//PRINTF("GetFeatures register_add   %x =0x%x  \r\n",register_add, FLASH_Status);
}

void SetFeatures(uint8_t register_add, uint8_t data)
{
	uint8_t FLASH_Status;
	uint32_t ECount=0;
	
	Select_Flash_CS();
	SPI_Write(SPINAND_CMD_SET_FEATURE);
	SPI_Write(register_add);
	SPI_Write(data);
	Release_Flash_CS();	
	//PRINTF("SetFeatures register_add   %x =0x%x \r\n",register_add, data);
}


#if 0
void UnlockGlobalBlockProtection(void)
{
	Power_Resume();
	WriteEnable();
	Select_Flash_CS();
	SPI_Write(E_ULBPR);
	Release_Flash_CS();		
	Power_Suspend();
}
#else
void UnlockGlobalBlockProtection(void)
{
	WriteEnable();
	Select_Flash_CS();
	SPI_Write(NAND_GLOBALBLOCKUNLOCK);
	Release_Flash_CS();

	SetFeatures(SPINAND_ADDR_Block_Lock, 0);
}
#endif

#if 0
void WaitForStatusRegister(uint8_t status)
{
	uint8_t FLASH_Status = 0;
	uint32_t ECount=0;
	do
	{
		Select_Flash_CS();
		SPI_Write(E_RDSR); 
		SPI_Read(&FLASH_Status,1);
		delay(3); 	
		ECount++;
		Release_Flash_CS();
	}	
	while ((FLASH_Status & status)&&(ECount<300000));//��û��д����һֱ�ȴ�������CS=0	
}
#else
void WaitForStatusRegister(uint8_t status)
{
	uint8_t FLASH_Status;
	uint32_t ECount=0;
	do
	{
		Select_Flash_CS();
		SPI_Write(SPINAND_CMD_GET_FEATURE);
		SPI_Write(SPINAND_ADDR_STATUS);
		SPI_Read(&FLASH_Status,1);
		ECount++;
		Release_Flash_CS();	
		//PRINTF("status =0x%x \r\n",FLASH_Status);
		delay(3); 
	}while((FLASH_Status & status) && (ECount<MASTER_TRANSFER_TIMEOUT0));
}
#endif

#if 0
uint32_t SpiFlash_ReadJedecID(void)
{
	uint32_t DeviceID=0;
	uint8_t DeviceID_8[4]={0};
	Power_Resume();
	Select_Flash_CS();
	SPI_Write(E_JEDEC);    	
	u_Delay(5);
	SPI_Read(DeviceID_8,4);
	DeviceID |= ((uint32_t)DeviceID_8[0] << 16);
	DeviceID |= ((uint16_t)DeviceID_8[1] << 8);
	DeviceID |= (uint16_t)DeviceID_8[2];
	Release_Flash_CS();
	Power_Suspend();
	return DeviceID;
}
#else
uint32_t SpiFlash_ReadJedecID(void)
{
	uint8_t DeviceID=0;
	uint8_t MarkerID=0;
	
	Select_Flash_CS();   	
	SPI_Write(NAND_READID);	    
	SPI_Write(0x00); 
	SPI_Read(&MarkerID,1);
	SPI_Read(&DeviceID,1);
	Release_Flash_CS();
	PRINTF("MarkerID=0x%x \r\n",MarkerID);
	PRINTF("DeviceID=0x%x \r\n",DeviceID);
	return DeviceID;
}
#endif


uint8_t SpiFlash_GetBusyBit(void)
{
	uint8_t FLASH_Status = 0;
	Power_Resume();
	Select_Flash_CS();
	SPI_Write(E_RDSR); 	
	SPI_Read(&FLASH_Status,1);
	Release_Flash_CS();
	Power_Suspend();
	return (FLASH_Status & SPI_FLASH_BUSY);
}

void SpiFlash_4KSector_Erase(uint32_t EraseAddr)
{
	Power_Resume();
	WriteEnable();
	Select_Flash_CS();
    	SPI_Write(E_SE);
	SPI_Write((uint8_t)(EraseAddr >> 16));
	SPI_Write((uint8_t)(EraseAddr>> 8));
	SPI_Write((uint8_t)(EraseAddr));	
	Release_Flash_CS();	
	WaitForStatusRegister(SPI_FLASH_BUSY);
	Power_Suspend();
}

void SpiFlash_64KBlock_Erase(uint32_t EraseAddr)
{
	Power_Resume();
	WriteEnable();
	Select_Flash_CS();
    	SPI_Write(E_BE);
	SPI_Write((uint8_t)(EraseAddr >> 16));
	SPI_Write((uint8_t)(EraseAddr>> 8));
	SPI_Write((uint8_t)(EraseAddr));	
	Release_Flash_CS();
	WaitForStatusRegister(SPI_FLASH_BUSY);
	Power_Suspend();
}  

void SpiFlash_ChipErase(void)
{
	Power_Resume();
	WriteEnable();
	Select_Flash_CS();
       SPI_Write(E_CE);
	Release_Flash_CS();		
	WaitForStatusRegister(SPI_FLASH_BUSY);
	Power_Suspend();
}

void SPI_NAND_EraseBlock(uint32_t EraseAddr)
{
	uint32_t Block, Page, Temp;
	int8_t i;
	
	Block = EraseAddr/(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE);
	Page = (EraseAddr%(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE))/NAND_FLASH_PAGE_SIZE;	
	Temp = (Block<<6) | Page;

	WriteEnable();
	Select_Flash_CS();			    
	SPI_Write(NAND_BLOCKERASE);	    	 
	SPI_Write((Temp>>16)&0xFF);
	SPI_Write((Temp>>8)&0xFF);
	SPI_Write((Temp)&0xFF);	
	Release_Flash_CS();	

	WaitForStatusRegister(SPINAND_IS_BUSY|E_FALI);
	//PRINTF("**************EraseBlock done****************\r\n");
}


#if 0
void SpiFlash_PageWrite(uint32_t addr,uint8_t* pBuf,uint16_t len)
{  
	WriteEnable();
	Select_Flash_CS();
	SPI_Write(E_PP);//ҳдָ��
	SPI_Write((uint8_t)(addr >> 16));
	SPI_Write((uint8_t)(addr>> 8));
	SPI_Write((uint8_t)(addr));
	while(len--)
	{
		SPI_Write(*pBuf);
		pBuf++;
	}
	Release_Flash_CS();	
	WaitForStatusRegister(SPI_FLASH_BUSY);
}

void SpiFlash_Write(uint32_t addr,uint8_t*pBuf, uint16_t len)
{
	uint8_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;
	Addr = addr%EFLASH_PAGE_SIZE;					/*	ȷ����ַ�ڵ�ҳ��λ��*/
	count = EFLASH_PAGE_SIZE - Addr;					/*	ȷ����ַ�ڵ�ҳʣ���д�ֽ���*/
	NumOfPage =  len/EFLASH_PAGE_SIZE;				/*	ȷ��Ҫд��������Ҫ������ҳ*/
	NumOfSingle = len%EFLASH_PAGE_SIZE;				/*	ȷ��Ҫд�����ݳ�ȥ��ҳ��ʣ���ֽ���*/
	Power_Resume();
	if (Addr == 0) 									/* д��ĵ�ַ��ҳ����*/
	{
		if (NumOfPage == 0)							/* д��������С��һҳ*/
			SpiFlash_PageWrite(addr, pBuf, len);
		else 										/* д������������һҳ*/
		{
			while (NumOfPage--)						/* д��ҳ��*/
			{
				SpiFlash_PageWrite(addr,pBuf, EFLASH_PAGE_SIZE);
				addr +=  EFLASH_PAGE_SIZE;
				pBuf += EFLASH_PAGE_SIZE;
			}
			SpiFlash_PageWrite(addr, pBuf,NumOfSingle);  	/* дʣ���*/
		}
	}
	else 											/* д��ĵ�ַ����ҳ����*/
	{
		if (NumOfPage == 0) 							/* д��������С��һҳ*/
		{
			if (NumOfSingle > count)					/* д�����������ڱ�ҳʣ���ֽ���*/
			{ 				
				temp = NumOfSingle - count;
				SpiFlash_PageWrite(addr,pBuf, count);		/* ��д�걾ҳʣ��*/
				addr +=  count;
				pBuf += count;
				SpiFlash_PageWrite(addr, pBuf, temp);		/* ʣ�µ�д����һҳ*/
			}
			else
				SpiFlash_PageWrite(addr, pBuf,len);	 	/* ��ҳ����װ��*/
		}
		else 										/* д������������һҳ*/
		{
			len -= count;
			NumOfPage =  len / EFLASH_PAGE_SIZE;
			NumOfSingle = len % EFLASH_PAGE_SIZE;
			SpiFlash_PageWrite(addr, pBuf, count);		/* ��д�걾ҳʣ�࣬����Ͱ�ҳ�������*/	
			addr +=  count;
			pBuf += count;
			while (NumOfPage--)
			{
				SpiFlash_PageWrite(addr,pBuf, EFLASH_PAGE_SIZE);
				addr +=  EFLASH_PAGE_SIZE;
				pBuf += EFLASH_PAGE_SIZE;
			}
			if (NumOfSingle != 0)
				SpiFlash_PageWrite(addr,pBuf,NumOfSingle);
		}
	}
	Power_Suspend();
}


#else
void SPI_NAND_WriteToCatch(uint8_t *pBuffer, uint16_t offset, uint32_t length)
{
	uint32_t i = 0;
	
	Select_Flash_CS();			    
	SPI_Write(NAND_PROGRAMLOAD);	    	 
	SPI_Write((offset>>8)&0xFF);
	SPI_Write((offset)&0xFF);

	for(i=0;i<length;i++)
	{
		SPI_Write(*pBuffer++);
	}	
	Release_Flash_CS();
}

void SPI_NAND_ProgramExecute(uint32_t addr)
{
	uint32_t Block, Page, Temp;
	
	Block = addr/(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE);
	Page = (addr%(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE))/NAND_FLASH_PAGE_SIZE;	
	Temp = (Block<<6) | Page;
	WriteEnable();
	
	Select_Flash_CS();				    
	SPI_Write(NAND_PROGRAMEXECUTE);	    	 
	SPI_Write((Temp>>16)&0xFF);
	SPI_Write((Temp>>8)&0xFF);
	SPI_Write((Temp)&0xFF);	
	Release_Flash_CS();	

	WaitForStatusRegister(SPINAND_IS_BUSY);
}

void SpiFlash_PageWrite(uint32_t addr,uint8_t* pBuf,uint16_t len)
{  
	uint16_t offset = addr%NAND_FLASH_PAGE_SIZE;
	
	SPI_NAND_WriteToCatch(pBuf, offset, len);
	SPI_NAND_ProgramExecute(addr);
}

void SpiFlash_Write(uint32_t addr,uint8_t*pBuf, uint16_t len)
{
	uint16_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;

	Addr = addr%NAND_FLASH_PAGE_SIZE;				/*	ȷ����ַ�ڵ�ҳ��λ��*/
	count = NAND_FLASH_CACHE_SIZE - Addr;				/*	ȷ����ַ�ڵ�ҳʣ���д�ֽ���*/
	NumOfPage =  len/NAND_FLASH_CACHE_SIZE;			/*	ȷ��Ҫд��������Ҫ������ҳ*/
	NumOfSingle = len%NAND_FLASH_CACHE_SIZE;			/*	ȷ��Ҫд�����ݳ�ȥ��ҳ��ʣ���ֽ���*/

	//PRINTF("Addr  = %d  \r\n",Addr);
	//PRINTF("count  = %d  \r\n",count);
	//PRINTF("NumOfPage  = %d  \r\n",NumOfPage);
	//PRINTF("NumOfSingle  = %d  \r\n",NumOfSingle);
	if (Addr == 0) 									/* д��ĵ�ַ��ҳ����*/
	{
		if (NumOfPage == 0)							/* д��������С��һҳ*/
		{
			SpiFlash_PageWrite(addr, pBuf, len);		
		}
		else 										/* д������������һҳ*/
		{
			while (NumOfPage--)						/* д��ҳ��*/
			{
				SpiFlash_PageWrite(addr,pBuf, NAND_FLASH_CACHE_SIZE);
				addr +=  NAND_FLASH_PAGE_SIZE;
				pBuf += NAND_FLASH_CACHE_SIZE;
			}
			if(NumOfSingle != 0)
			{
				SpiFlash_PageWrite(addr, pBuf,NumOfSingle);  	/* дʣ���*/
			}
		}
	}
	else 											/* д��ĵ�ַ����ҳ����*/
	{
		if (NumOfPage == 0) 							/* д��������С��һҳ*/
		{
			if (NumOfSingle > count)					/* д�����������ڱ�ҳʣ���ֽ���*/
			{ 			
				temp = NumOfSingle - count;
				SpiFlash_PageWrite(addr,pBuf, count);		/* ��д�걾ҳʣ��*/
				addr +=  (count+128);
				pBuf += count;
				SpiFlash_PageWrite(addr, pBuf, temp);		/* ʣ�µ�д����һҳ*/
			}
			else
			{
				SpiFlash_PageWrite(addr, pBuf,len);	 	/* ��ҳ����װ��*/
			}
		}
		else 										/* д������������һҳ*/
		{
			len -= count;
			NumOfPage =  len / NAND_FLASH_CACHE_SIZE;
			NumOfSingle = len % NAND_FLASH_CACHE_SIZE;
			SpiFlash_PageWrite(addr, pBuf, count);		/* ��д�걾ҳʣ�࣬����Ͱ�ҳ�������*/	
			addr +=  (count+128);
			pBuf += count;

			while (NumOfPage--)
			{
				SpiFlash_PageWrite(addr,pBuf, NAND_FLASH_CACHE_SIZE);
				addr +=  NAND_FLASH_PAGE_SIZE;
				pBuf += NAND_FLASH_CACHE_SIZE;
			}
			if (NumOfSingle != 0)
			{
				SpiFlash_PageWrite(addr,pBuf,NumOfSingle);
			}
		}
	}
}

#endif



#if 0
void SpiFlash_Read( uint32_t addr,uint8_t*pBuf , uint32_t len)
{
	Power_Resume();
	Select_Flash_CS();
	
	SPI_Write(E_READ);//д��ȡ����ָ��    
	SPI_Write((uint8_t)(addr >> 16));
	SPI_Write((uint8_t)(addr>> 8));
	SPI_Write((uint8_t)(addr));
	SPI_Read(pBuf,len);
	Release_Flash_CS(); 
	Power_Suspend();
}
#else
void SpiNand_ReadToCatch(uint32_t addr)
{
	uint32_t Block, Page, Temp;

	Block = addr/(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE);
	Page = (addr%(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE))/NAND_FLASH_PAGE_SIZE;	
	Temp = (Block<<6) | Page;

	Select_Flash_CS();				    
	SPI_Write(NAND_PAGEREADTOCATCH);	    	 
	SPI_Write((Temp>>16)&0xFF);
	SPI_Write((Temp>>8)&0xFF);
	SPI_Write((Temp)&0xFF);	
	Release_Flash_CS();	

	WaitForStatusRegister(SPINAND_IS_BUSY);
	//PRINTF("**************read to catch done****************\r\n");
}

void SpiNand_ReadFromCatch (uint8_t *pBuffer, uint16_t offset, uint32_t length)
{
 	uint16_t i;
	Select_Flash_CS();			    
	SPI_Write(NAND_READFROMCATCH);	    	 
	SPI_Write((offset>>8)&0xFF);
	SPI_Write((offset)&0xFF);
	SPI_Write(0xFF); 		  			/*need a dummy byte in read command	*/
	SPI_Read(pBuffer,length);
	Release_Flash_CS();

	//PRINTF("******read from catch done********\r\n");
	for(i=0; i<length; i++){
		PRINTF("   %d = %d  ",i , *pBuffer++);
	}
}


void SpiFlash_PageRead( uint32_t addr,uint8_t*pBuf , uint32_t len)
{
	uint16_t offset;
	offset = addr%NAND_FLASH_PAGE_SIZE;

	SpiNand_ReadToCatch(addr);	
	SpiNand_ReadFromCatch(pBuf, offset, len);
}

void SpiFlash_Read(uint32_t addr,uint8_t*pBuf, uint32_t len)
{
	uint16_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;

	Addr = addr%NAND_FLASH_PAGE_SIZE;				/*	ȷ����ַ�ڵ�ҳ��λ��*/
	count = NAND_FLASH_CACHE_SIZE - Addr;				/*	ȷ����ַ�ڵ�ҳʣ��ɶ�ȡ����*/
	NumOfPage =  len/NAND_FLASH_CACHE_SIZE;			/*	ȷ��Ҫ��ȡ������Ҫ������ҳ*/
	NumOfSingle = len%NAND_FLASH_CACHE_SIZE;		/*	ȷ��Ҫ��ȡ���ݳ�ȥ��ҳ��ʣ���ֽ���*/

	//PRINTF("Addr  = %d  \r\n",Addr);
	//PRINTF("count  = %d  \r\n",count);
	//PRINTF("NumOfPage  = %d  \r\n",NumOfPage);
	//PRINTF("NumOfSingle  = %d  \r\n",NumOfSingle);
	if (Addr == 0) 									/* ��ȡ�ĵ�ַ��ҳ����*/
	{
		if (NumOfPage == 0)							/* ��ȡ������С��һҳ*/
		{
			SpiFlash_PageRead(addr, pBuf, len);
		}
		else 										/* ��ȡ����������һҳ*/
		{
			while (NumOfPage--)						/* ��ȡ��ҳ��*/
			{
				SpiFlash_PageRead(addr,pBuf, NAND_FLASH_CACHE_SIZE);
				addr +=  NAND_FLASH_PAGE_SIZE;
				pBuf += NAND_FLASH_CACHE_SIZE;
			}
			if(NumOfSingle != 0)
			{
				SpiFlash_PageRead(addr, pBuf,NumOfSingle);  	/* ��ȡʣ���*/
			}
		}
	}
	else 											/* ��ȡ�ĵ�ַ����ҳ����*/
	{
		if (NumOfPage == 0) 							/* ��ȡ������С��һҳ*/
		{
			if (NumOfSingle > count)					/* ��ȡ���������ڱ�ҳʣ���ֽ���*/
			{ 	
				temp = NumOfSingle - count;
				SpiFlash_PageRead(addr,pBuf, count);		/* �ȶ�ȡ��ҳ�ɶ�ȡ����*/
				addr +=  (count+128);
				pBuf += count;
				SpiFlash_PageRead(addr, pBuf, temp);		/* Ȼ���ȡ��һҳ��Ҫ��ȡ������*/
			}
			else
			{
				SpiFlash_PageRead(addr, pBuf,len);	 	/* ��ȡ��ҳ�ɶ�����*/
			}
		}
		else 											/* ��ȡ����������һҳ*/
		{
			len -= count;
			NumOfPage =  len / NAND_FLASH_CACHE_SIZE;
			NumOfSingle = len % NAND_FLASH_CACHE_SIZE;
			SpiFlash_PageRead(addr, pBuf, count);			/* �ȶ�ȡ��ҳʣ�࣬����Ͱ�ҳ���������ȡ*/	
			addr +=  (count+128);
			pBuf += count;
			
			while (NumOfPage--)
			{
				SpiFlash_PageRead(addr,pBuf, NAND_FLASH_CACHE_SIZE);
				addr +=  NAND_FLASH_PAGE_SIZE;
				pBuf += NAND_FLASH_CACHE_SIZE;
			}
			if (NumOfSingle != 0)
			{
				SpiFlash_PageRead(addr,pBuf,NumOfSingle);
			}
		}
	}
}
#endif


#if 0
void DMA_SpiFlash_Read( uint32_t addr,uint8_t*pBuf , uint32_t len)
{
	dma_spi_read = false;
	Power_Resume();
	Select_Flash_CS();
	
	SPI_Write(E_READ);//д��ȡ����ָ��    
	SPI_Write((uint8_t)(addr >> 16));
	SPI_Write((uint8_t)(addr>> 8));
	SPI_Write((uint8_t)(addr));
	DMA_SPI_Read(pBuf,len);	
}

void DMA_Clean_SpiFlash_Read( uint32_t addr,uint8_t*pBuf , uint32_t len)
{
	Select_Flash_CS();
	SPI_Write(E_READ);//д��ȡ����ָ��    
	SPI_Write((uint8_t)(addr >> 16));
	SPI_Write((uint8_t)(addr>> 8));
	SPI_Write((uint8_t)(addr));
	CleanDisplayMode = true;
	DMA_SPI_Read(pBuf,len);	
}
#else
void DMA_SpiFlash_Read( uint32_t addr,uint8_t*pBuf , uint32_t len)
{
	dma_spiflash_read = true;
	SpiFlash_Read(addr, pBuf, len);
}

void DMA_Clean_SpiFlash_Read( uint32_t addr,uint8_t*pBuf , uint32_t len)
{
	CleanDisplayMode = true;
	dma_spiflash_read = true;
	SpiFlash_Read(addr, pBuf, len);
}
#endif

void SpiFlash_IO_Init(void)
{         
	GPIO_PinInit(GPIOB, 0u, \
                 &(gpio_pin_config_t){kGPIO_DigitalOutput, (1)}) ;
}

void SpiFlash_Init(void)
{
	SpiFlash_IO_Init();
	UnlockGlobalBlockProtection();
	SpiFlash_ReadJedecID();
}


