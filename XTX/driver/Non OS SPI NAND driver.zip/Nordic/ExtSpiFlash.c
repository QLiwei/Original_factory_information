#include "headfile.h"


#define EFLASH_PAGE_SIZE	256

#define NAND_FLASH_PAGE_SIZE		(2048+128)
#define NAND_FLASH_CACHE_SIZE		(2048)

#define NAND_FLASH_BLOCKNUM			(1024)
#define NAND_FLASH_BLOCK_PAGENUM	(64)

#define FLASH_CS_OUT		nrf_gpio_pin_dir_set(FLASH_CS_PIN, NRF_GPIO_PIN_DIR_OUTPUT)
#define FLASH_CLK_OUT		nrf_gpio_pin_dir_set(FLASH_CLK_PIN, NRF_GPIO_PIN_DIR_OUTPUT)
#define FLASH_DI_OUT		nrf_gpio_pin_dir_set(FLASH_DI_PIN, NRF_GPIO_PIN_DIR_OUTPUT)
#define FLASH_DO_OUT		nrf_gpio_pin_dir_set(FLASH_DO_PIN, NRF_GPIO_PIN_DIR_OUTPUT)
#define FLASH_DO_IN		       nrf_gpio_pin_dir_set(FLASH_DO_PIN, NRF_GPIO_PIN_DIR_INPUT)

#define FLASH_CS_H			nrf_gpio_pin_set(FLASH_CS_PIN)
#define FLASH_CS_L			nrf_gpio_pin_clear(FLASH_CS_PIN)

#define FLASH_CLK_H			nrf_gpio_pin_set(FLASH_CLK_PIN)
#define FLASH_CLK_L			nrf_gpio_pin_clear(FLASH_CLK_PIN)

#define FLASH_DI_H			nrf_gpio_pin_set(FLASH_DI_PIN)
#define FLASH_DI_L			nrf_gpio_pin_clear(FLASH_DI_PIN)

#define FLASH_DO_H			nrf_gpio_pin_set(FLASH_DO_PIN)
#define FLASH_DO_L			nrf_gpio_pin_clear(FLASH_DO_PIN)
#define FLASH_DO_DATA	       nrf_gpio_pin_read(FLASH_DO_PIN)



#define SPI_FLASH_BUSY		0x01

#define E_JEDEC		0x9f
#define E_RDSR		0x05
#define E_WREN		0x06
#define E_WRDI		0x04
#define E_ULBPR		0x98
#define E_CE			0xc7
#define E_SE			0x20
#define E_BE			0xd8
#define E_PP			0x02
#define E_READ		0x03
#define E_DPD		0xb9
#define E_RDPD		0xab

#define NAND_WRITEENABLE						0x06	/* spi nand write enable */
#define NAND_WRITEDISABLE						0x04	/* spi nand write disable */
#define NAND_READID							0x9f	/* read spi nand id */
#define NAND_GLOBALBLOCKUNLOCK				0x98	/* spi global block unlock */
#define NAND_PAGEREADTOCATCH					0x13	/* read page data to spi nand cache */
#define NAND_READFROMCATCH                			0x03    	/* read from spi nand cache */
#define NAND_PROGRAMLOAD						0X02    	/* program load random data */
#define NAND_PROGRAMLOAD_X4					0X32    	/* program load random data x4*/
#define NAND_PROGRAMEXECUTE					0x10    	/* program load execute */
#define NAND_PROGRAMLOADRANDOMDATA 		0X84    	/* program load random data */
#define NAND_PROGRAMLOADRANDOMDATA_X4        0Xc4    	/* program load random data x4*/

#define NAND_BLOCKERASE						0xd8	/* erase spi nand block 128K */		

#define SPINAND_CMD_GET_FEATURE 		0x0f    	/* get spi nand feature */
#define SPINAND_CMD_SET_FEATURE 		0x1f    	/* set spi nand feature */

#define SPINAND_ADDR_STATUS     		0xc0    	/* get feature status addr */
#define SPINAND_ADDR_FEATURE    		0xb0	/* set feature addr */
#define SPINAND_ADDR_Block_Lock     		0xa0    	/* get feature Block_Lock addr */

#define E_FALI          (1 << 2)        		/* erase fail */
#define P_FAIL          (1 << 3)        		/* write fail */
#define SPINAND_IS_BUSY (1 << 0)	/* PROGRAM EXECUTE, PAGE READ, BLOCK ERASE, or RESET command is executing */
#define SPINAND_WRITE_EN (1 << 1)	/* Write enable */

#define MASTER_TRANSFER_TIMEOUT0     (5000U)             /*! Transfer timeout of master - 5s */


void u_Delay(int l)
{
	while(l--); 
}
void Select_Flash_CS(void)
{
	FLASH_CS_L;
}

void Release_Flash_CS(void)
{
	FLASH_CS_H;
}


#if 0
/**********************************************
//
//д�����

**********************************************/
void SPI_Write(uint8 data)
{
	int8 i;  
	for(i=0;i<8;i++)
	{  
		FLASH_CLK_L;
		if(data&0x80)
			FLASH_DI_H;
		else
			FLASH_DI_L;
 
		FLASH_CLK_H;
  
		data<<=1;
	}  
}

/**********************************************
//
//�������

**********************************************/
uint8 SPI_Read(void)
{
	int8 i;
	uint8 data=0;    
	for(i=7;i>=0;i--)
	{
		FLASH_CLK_L;

		FLASH_CLK_H;
		if(FLASH_DO_DATA)
			data|=(0x1<<i);

	}  
	return data;
}
#else
uint8 Flash_SpiReadWrite(uint8 data)
{
	volatile uint8 dummy = 0;
	
	NRF_SPI0->TXD = data;
	while(NRF_SPI0->EVENTS_READY != 1);
	NRF_SPI0->EVENTS_READY = 0U;
	return NRF_SPI0->RXD;
}
#endif
#if 0 
void SpiFlash_Enable_IO(void)
{
	FLASH_CS_OUT;          
	FLASH_CLK_OUT;        
	FLASH_DI_OUT;       
	FLASH_CS_H;
	FLASH_CLK_H;
	FLASH_DI_H;
}

void SpiFlash_Disable_IO(void)
{
	nrf_gpio_pin_dir_set(FLASH_CS_PIN, NRF_GPIO_PIN_DIR_INPUT);	
	nrf_gpio_pin_dir_set(FLASH_CLK_PIN, NRF_GPIO_PIN_DIR_INPUT);	
	nrf_gpio_pin_dir_set(FLASH_DI_PIN, NRF_GPIO_PIN_DIR_INPUT);	
	nrf_gpio_pin_dir_set(FLASH_DO_PIN, NRF_GPIO_PIN_DIR_INPUT);
}
#else
void SpiFlash_Enable_IO(void)
{
	NRF_SPI0->ENABLE = 0;
	NRF_SPI0->PSELSCK = FLASH_CLK_PIN;
	NRF_SPI0->PSELMISO = FLASH_DO_PIN;
	NRF_SPI0->PSELMOSI = FLASH_DI_PIN;
	NRF_SPI0->FREQUENCY = (uint32) 0x80000000;
	NRF_SPI0->CONFIG = 0x0;
	NRF_SPI0->EVENTS_READY = 0;
	NRF_SPI0->ENABLE = (SPI_ENABLE_ENABLE_Enabled << SPI_ENABLE_ENABLE_Pos);

	nrf_gpio_cfg_output(FLASH_CLK_PIN);
	nrf_gpio_cfg_output(FLASH_DI_PIN);
	nrf_gpio_cfg_output(FLASH_DO_PIN);

	FLASH_CS_OUT;    
}

void SpiFlash_Disable_IO(void)
{
	NRF_SPI0->ENABLE = 0;

	nrf_gpio_cfg_input(FLASH_CLK_PIN, NRF_GPIO_PIN_NOPULL);
	nrf_gpio_cfg_input(FLASH_DI_PIN, NRF_GPIO_PIN_NOPULL);
	nrf_gpio_cfg_input(FLASH_DO_PIN, NRF_GPIO_PIN_NOPULL);

	nrf_gpio_pin_dir_set(FLASH_CS_PIN, NRF_GPIO_PIN_DIR_INPUT);	
}
#endif
void Force_NordicFlash(void)
{
	if(SUSPEND_NORDIC_USE_FLASH)
		return;
	if(Flash_Set_Access(F_NORDIC))
	{
		SpiFlash_Enable_IO();
		FORCE_NORDIC_FLASH_FLAG =true;
	}
}
void Free_NordicFlash(void)
{
	if(SUSPEND_NORDIC_USE_FLASH)
		return;
	if(Flash_Set_Access(F_FREESCAL))
	{
		SpiFlash_Disable_IO();
		FORCE_NORDIC_FLASH_FLAG =false;
	}	
}

bool SetFlash_Nordic(void)
{
	if(FORCE_NORDIC_FLASH_FLAG)
		return true;
	if(Flash_Set_Access(F_NORDIC))
	{
		SpiFlash_Enable_IO();
		return true;
	}
	return false;
}

bool SetFlash_Freescal(void)
{
	if(FORCE_NORDIC_FLASH_FLAG)
		return true;
	if(Flash_Set_Access(F_FREESCAL))
	{
		SpiFlash_Disable_IO();
		return true;
	}
	return false;
}

void Power_Suspend(void)
{
/*
	Select_Flash_CS();
        SPI_Write(E_DPD);
	Release_Flash_CS();	

*/
}    

void Power_Resume(void)
{
/*
	Select_Flash_CS();
        SPI_Write(E_RDPD);
	Release_Flash_CS();	
*/
}    

uint8 GetFeatures(uint8 register_add)
{
	uint8 FLASH_Status;
	uint32 ECount=0;
	
	Select_Flash_CS();
	Flash_SpiReadWrite(SPINAND_CMD_GET_FEATURE);
	Flash_SpiReadWrite(register_add);
	FLASH_Status = Flash_SpiReadWrite(0xff);
	Release_Flash_CS();	
	PRINTF("GetFeatures register_add   %x =0x%x  \r\n",register_add, FLASH_Status);
	return FLASH_Status;
}

void SetFeatures(uint8 register_add, uint8 data)
{
	uint8 FLASH_Status;
	uint32 ECount=0;
	
	Select_Flash_CS();
	Flash_SpiReadWrite(SPINAND_CMD_SET_FEATURE);
	Flash_SpiReadWrite(register_add);
	Flash_SpiReadWrite(data);
	Release_Flash_CS();	
	//PRINTF("SetFeatures register_add   %x =0x%x \r\n",register_add, data);
	return ;
}


#if 0
void WriteEnable(void)
{
	Select_Flash_CS();
        SPI_Write(E_WREN);
	Release_Flash_CS();	
}
#else
void WriteEnable(void)
{
	uint8 status=0x00;
	uint32 ECount=0;
	
	Select_Flash_CS();
	Flash_SpiReadWrite(NAND_WRITEENABLE);
	Release_Flash_CS();	

	do
	{
		Select_Flash_CS();
		Flash_SpiReadWrite(SPINAND_CMD_GET_FEATURE);
		Flash_SpiReadWrite(SPINAND_ADDR_STATUS);
		status = Flash_SpiReadWrite(0xff);
		ECount++;
		Release_Flash_CS();	
		PRINTF("status =0x%x \r\n",status);
	}while((!(status & SPINAND_WRITE_EN)) && (ECount<MASTER_TRANSFER_TIMEOUT0));

	//PRINTF("WriteEnable \r\n");
}

#endif

void WriteDisable(void)
{
        Select_Flash_CS();
        Flash_SpiReadWrite(NAND_WRITEDISABLE);
        Release_Flash_CS();	
}

#if 0
void UnlockGlobalBlockProtection(void)
{
	Power_Resume();
	WriteEnable();
	Select_Flash_CS();
       SPI_Write(E_ULBPR);
	Release_Flash_CS();		
	Power_Suspend();
}
#else
void UnlockGlobalBlockProtection(void)
{
	WriteEnable();
	Select_Flash_CS();
       	Flash_SpiReadWrite(NAND_GLOBALBLOCKUNLOCK);
	Release_Flash_CS();	
	
	GetFeatures(SPINAND_ADDR_STATUS);
}
#endif

#if 0
void WaitForStatusRegister(uint8 status)
{
	uint8 FLASH_Status = 0;
	uint32 ECount=0;
	Select_Flash_CS();
	SPI_Write(E_RDSR); 
	FLASH_DO_IN;
	do
	{
		FLASH_Status =  SPI_Read();
		nrf_delay_us(10); 
		ECount++;
	}	
	while ((FLASH_Status & status)&&(ECount<300000)); 
	FLASH_DO_OUT;
	Release_Flash_CS();
}
#else
void WaitForStatusRegister(uint8 status)
{
	uint8 FLASH_Status;
	uint32 ECount=0;

	do
	{
		Select_Flash_CS();
		Flash_SpiReadWrite(SPINAND_CMD_GET_FEATURE);
		Flash_SpiReadWrite(SPINAND_ADDR_STATUS);
		FLASH_Status = Flash_SpiReadWrite(0xff);
		ECount++;
		Release_Flash_CS();	
		//Delayus(3);
		PRINTF("status =0x%x \r\n",FLASH_Status);
	}while((FLASH_Status & status) && (ECount<MASTER_TRANSFER_TIMEOUT0));
}
#endif

#if 0
uint32 SpiFlash_ReadJedecID(void)
{
	uint32 DeviceID=0;
	Power_Resume();
	Select_Flash_CS();
	SPI_Write(E_JEDEC);    
	FLASH_DO_IN;	
	u_Delay(5);
	DeviceID |= ((uint32)SPI_Read() << 16);
	DeviceID |= ((uint16)SPI_Read() << 8);
	DeviceID |= SPI_Read();
	FLASH_DO_OUT;
	Release_Flash_CS();
	Power_Suspend();
	return DeviceID;
}
#else
uint32 SpiFlash_ReadJedecID(void)
{
	uint8 DeviceID=0;
	uint8 MarkerID=0;

	WriteEnable();
	Select_Flash_CS();
	Flash_SpiReadWrite(NAND_READID);  
	Flash_SpiReadWrite(0xFF); 	
	MarkerID = Flash_SpiReadWrite(0xFF);
	DeviceID = Flash_SpiReadWrite(0xFF);
	Release_Flash_CS();
	PRINTF("nodick   MarkerID=0x%x \r\n",MarkerID);
	PRINTF("nodick   DeviceID=0x%x \r\n",DeviceID);
	return DeviceID;
}
#endif

uint8 SpiFlash_GetBusyBit(void)
{
#if 0
	uint8 FLASH_Status = 0;
	Power_Resume();
	Select_Flash_CS();
	SPI_Write(E_RDSR); 
	FLASH_DO_IN;
	FLASH_Status =  SPI_Read();
	FLASH_DO_OUT;
	Release_Flash_CS();
	Power_Suspend();
	return (FLASH_Status & SPI_FLASH_BUSY);
#endif
}

void SpiFlash_4KSector_Erase(uint32 EraseAddr)
{
#if 0
	if(SetFlash_Nordic())
	{
		Power_Resume();
		WriteEnable();
		Select_Flash_CS();
	    	SPI_Write(E_SE);
		SPI_Write((uint8)(EraseAddr >> 16));
		SPI_Write((uint8)(EraseAddr>> 8));
		SPI_Write((uint8)(EraseAddr));	
		Release_Flash_CS();	
		WaitForStatusRegister(SPI_FLASH_BUSY);
		Power_Suspend();
		SetFlash_Freescal();
	}
	else
	{
		Flash_Erase(EraseAddr,F_SECTOR);
	}
#endif
}

void SpiFlash_64KBlock_Erase(uint32 EraseAddr)
{
#if 0
	if(SetFlash_Nordic())
	{
		Power_Resume();
		WriteEnable();
		Select_Flash_CS();
	    	SPI_Write(E_BE);
		SPI_Write((uint8)(EraseAddr >> 16));
		SPI_Write((uint8)(EraseAddr>> 8));
		SPI_Write((uint8)(EraseAddr));	
		Release_Flash_CS();
		WaitForStatusRegister(SPI_FLASH_BUSY);
		Power_Suspend();
		SetFlash_Freescal();
	}
	else
	{
		Flash_Erase(EraseAddr,F_BLOCK);
	}
#endif
}  

void SpiFlash_ChipErase(void)
{
#if 0
	if(SetFlash_Nordic())
	{
		Power_Resume();
		WriteEnable();
		Select_Flash_CS();
	       SPI_Write(E_CE);
		Release_Flash_CS();		
		WaitForStatusRegister(SPI_FLASH_BUSY);
		Power_Suspend();
		SetFlash_Freescal();
	}
	else
	{
		Flash_Erase(0x00000000UL,F_CHIP);
	}
#endif
}

void SPI_NAND_EraseBlock(uint32 EraseAddr)
{
	uint32 Block, Page, Temp;
	
	Block = EraseAddr/(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE);
	Page = (EraseAddr%(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE))/NAND_FLASH_PAGE_SIZE;	
	Temp = (Block<<6) | Page;

	UnlockGlobalBlockProtection();

	WriteEnable();
	
	Select_Flash_CS();			    
	Flash_SpiReadWrite(NAND_BLOCKERASE);	    	 
	Flash_SpiReadWrite((Temp>>16)&0xFF);
	Flash_SpiReadWrite((Temp>>8)&0xFF);
	Flash_SpiReadWrite((Temp)&0xFF);	
	Release_Flash_CS();	

	WaitForStatusRegister(SPINAND_IS_BUSY|E_FALI);
	PRINTF("**************EraseBlock done****************\r\n");
}


#if 0
void SpiFlash_PageWrite(uint32 addr,uint8* pBuf,uint16 len)
{  
	WriteEnable();
	Select_Flash_CS();
	SPI_Write(E_PP);//ҳдָ��
	SPI_Write((uint8)(addr >> 16));
	SPI_Write((uint8)(addr>> 8));
	SPI_Write((uint8)(addr));
	while(len--)
	{
		SPI_Write(*pBuf);
		pBuf++;
	}
	Release_Flash_CS();	
	WaitForStatusRegister(SPI_FLASH_BUSY);
}

void SpiFlash_Write(uint32 addr,uint8*pBuf, uint16 len)
{
	if(SetFlash_Nordic())
	{
		uint8 NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;
		Addr = addr%EFLASH_PAGE_SIZE;					/*	ȷ����ַ�ڵ�ҳ��λ��*/
		count = EFLASH_PAGE_SIZE - Addr;					/*	ȷ����ַ�ڵ�ҳʣ���д�ֽ���*/
		NumOfPage =  len/EFLASH_PAGE_SIZE;				/*	ȷ��Ҫд��������Ҫ������ҳ*/
		NumOfSingle = len%EFLASH_PAGE_SIZE;				/*	ȷ��Ҫд�����ݳ�ȥ��ҳ��ʣ���ֽ���*/
		Power_Resume();
		if (Addr == 0) 									/* д��ĵ�ַ��ҳ����*/
		{
			if (NumOfPage == 0)							/* д��������С��һҳ*/
				SpiFlash_PageWrite(addr, pBuf, len);
			else 										/* д������������һҳ*/
			{
				while (NumOfPage--)						/* д��ҳ��*/
				{
					SpiFlash_PageWrite(addr,pBuf, EFLASH_PAGE_SIZE);
					addr +=  EFLASH_PAGE_SIZE;
					pBuf += EFLASH_PAGE_SIZE;
				}
				SpiFlash_PageWrite(addr, pBuf,NumOfSingle);  	/* дʣ���*/
			}
		}
		else 											/* д��ĵ�ַ����ҳ����*/
		{
			if (NumOfPage == 0) 							/* д��������С��һҳ*/
			{
				if (NumOfSingle > count)					/* д�����������ڱ�ҳʣ���ֽ���*/
				{ 				
					temp = NumOfSingle - count;
					SpiFlash_PageWrite(addr,pBuf, count);		/* ��д�걾ҳʣ��*/
					addr +=  count;
					pBuf += count;
					SpiFlash_PageWrite(addr, pBuf, temp);		/* ʣ�µ�д����һҳ*/
				}
				else
					SpiFlash_PageWrite(addr, pBuf,len);	 	/* ��ҳ����װ��*/
			}
			else 										/* д������������һҳ*/
			{
				len -= count;
				NumOfPage =  len / EFLASH_PAGE_SIZE;
				NumOfSingle = len % EFLASH_PAGE_SIZE;
				SpiFlash_PageWrite(addr, pBuf, count);		/* ��д�걾ҳʣ�࣬����Ͱ�ҳ�������*/	
				addr +=  count;
				pBuf += count;
				while (NumOfPage--)
				{
					SpiFlash_PageWrite(addr,pBuf, EFLASH_PAGE_SIZE);
					addr +=  EFLASH_PAGE_SIZE;
					pBuf += EFLASH_PAGE_SIZE;
				}
				if (NumOfSingle != 0)
					SpiFlash_PageWrite(addr,pBuf,NumOfSingle);
			}
		}
		Power_Suspend();
		SetFlash_Freescal();
	}
	else
	{
		Flash_Write(addr,pBuf,len);
	}
}

#else
void SPI_NAND_WriteToCatch(uint8 *pBuffer, uint16 offset, uint32 length)
{
	uint32 i = 0;
	PRINTF("***************data  = %d     %d\r\n",*pBuffer,*(pBuffer+1));
	Select_Flash_CS();			    
	Flash_SpiReadWrite(NAND_PROGRAMLOAD);	    	 
	Flash_SpiReadWrite((offset>>8)&0xFF);
	Flash_SpiReadWrite((offset)&0xFF);
	
	for(i=0;i<length;i++)
	{
		Flash_SpiReadWrite(*pBuffer++);
	}	
	Release_Flash_CS();
}

void SPI_NAND_ProgramExecute(uint32 addr)
{
	uint32 Block, Page, Temp;
	
	Block = addr/(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE);
	Page = (addr%(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE))/NAND_FLASH_PAGE_SIZE;	
	Temp = (Block<<6) | Page;
	WriteEnable();
	
	Select_Flash_CS();				    
	Flash_SpiReadWrite(NAND_PROGRAMEXECUTE);	    	 
	Flash_SpiReadWrite((Temp>>16)&0xFF);
	Flash_SpiReadWrite((Temp>>8)&0xFF);
	Flash_SpiReadWrite((Temp)&0xFF);	
	Release_Flash_CS();	

	WaitForStatusRegister(SPINAND_IS_BUSY);
	PRINTF("**************execute done****************\r\n");
}

void SpiFlash_PageWrite(uint32 addr,uint8* pBuf,uint16 len)
{  
	uint16 offset = addr%NAND_FLASH_PAGE_SIZE;
	
	SPI_NAND_WriteToCatch(pBuf, offset, len);
	SPI_NAND_ProgramExecute(addr);
}

void SpiFlash_Write(uint32 addr,uint8*pBuf, uint16 len)
{
	uint16_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;

	Addr = addr%NAND_FLASH_PAGE_SIZE;				/*	ȷ����ַ�ڵ�ҳ��λ��*/
	count = NAND_FLASH_CACHE_SIZE - Addr;				/*	ȷ����ַ�ڵ�ҳʣ���д�ֽ���*/
	NumOfPage =  len/NAND_FLASH_CACHE_SIZE;			/*	ȷ��Ҫд��������Ҫ������ҳ*/
	NumOfSingle = len%NAND_FLASH_CACHE_SIZE;			/*	ȷ��Ҫд�����ݳ�ȥ��ҳ��ʣ���ֽ���*/

	PRINTF("Addr  = %d  \r\n",Addr);
	PRINTF("count  = %d  \r\n",count);
	PRINTF("NumOfPage  = %d  \r\n",NumOfPage);
	PRINTF("NumOfSingle  = %d  \r\n",NumOfSingle);
	if (Addr == 0) 									/* д��ĵ�ַ��ҳ����*/
	{
			PRINTF("111111111111111111111\r\n");
		if (NumOfPage == 0)							/* д��������С��һҳ*/
		{
			SpiFlash_PageWrite(addr, pBuf, len);		
		}
		else 										/* д������������һҳ*/
		{
			PRINTF("222222222222222\r\n");
			while (NumOfPage--)						/* д��ҳ��*/
			{
				SpiFlash_PageWrite(addr,pBuf, NAND_FLASH_CACHE_SIZE);
				addr +=  NAND_FLASH_PAGE_SIZE;
				pBuf += NAND_FLASH_CACHE_SIZE;
			}
			if(NumOfSingle != 0)
			{
				PRINTF("33333333333333333\r\n");
				SpiFlash_PageWrite(addr, pBuf,NumOfSingle);  	/* дʣ���*/
			}
		}
	}
	else 											/* д��ĵ�ַ����ҳ����*/
	{
		if (NumOfPage == 0) 							/* д��������С��һҳ*/
		{
			if (NumOfSingle > count)					/* д�����������ڱ�ҳʣ���ֽ���*/
			{ 		
			PRINTF("1444444444444444\r\n");
				temp = NumOfSingle - count;
				SpiFlash_PageWrite(addr,pBuf, count);		/* ��д�걾ҳʣ��*/
				addr +=  (count+128);
				pBuf += count;
				SpiFlash_PageWrite(addr, pBuf, temp);		/* ʣ�µ�д����һҳ*/
			}
			else
			{
			PRINTF("155555555555\r\n");
				SpiFlash_PageWrite(addr, pBuf,len);	 	/* ��ҳ����װ��*/
			}
		}
		else 										/* д������������һҳ*/
		{
			PRINTF("6666666666666666\r\n");
			len -= count;
			NumOfPage =  len / NAND_FLASH_CACHE_SIZE;
			NumOfSingle = len % NAND_FLASH_CACHE_SIZE;
			SpiFlash_PageWrite(addr, pBuf, count);		/* ��д�걾ҳʣ�࣬����Ͱ�ҳ�������*/	
			addr +=  (count+128);
			pBuf += count;

			while (NumOfPage--)
			{
			PRINTF("7777777777777777777777\r\n");
				SpiFlash_PageWrite(addr,pBuf, NAND_FLASH_CACHE_SIZE);
				addr +=  NAND_FLASH_PAGE_SIZE;
				pBuf += NAND_FLASH_CACHE_SIZE;
			}
			if (NumOfSingle != 0)
			{
			PRINTF("888888888888888888\r\n");
				SpiFlash_PageWrite(addr,pBuf,NumOfSingle);
			}
		}
	}
}

#endif


#if 0 
void SpiFlash_Read( uint32 addr,uint8*pBuf , uint16 len)
{
	if(SetFlash_Nordic())
	{
		Power_Resume();
		Select_Flash_CS();
		SPI_Write(E_READ);//д��ȡ����ָ��    
		SPI_Write((uint8)(addr >> 16));
		SPI_Write((uint8)(addr>> 8));
		SPI_Write((uint8)(addr));
		FLASH_DO_IN;
		while (len--) 
		{
			*pBuf = SPI_Read();
			pBuf++;
		}
		FLASH_DO_OUT;
		Release_Flash_CS(); 
		Power_Suspend();
		SetFlash_Freescal();
	}
	else
	{
		Flash_Read(addr,pBuf,len);
	}

}

void SpiFlash_Read_TP_Firmware( uint32 addr,uint8*pBuf , uint16 len)
{
	if(SetFlash_Nordic())
	{
	
		Select_Flash_CS();
		SPI_Write(E_READ);//д��ȡ����ָ��    
		SPI_Write((uint8)(addr >> 16));
		SPI_Write((uint8)(addr>> 8));
		SPI_Write((uint8)(addr));
		FLASH_DO_IN;
		while (len--) 
		{
			*pBuf = SPI_Read();
			pBuf++;
		}
		FLASH_DO_OUT;
		Release_Flash_CS(); 
	
		SetFlash_Freescal();
	}
	else
	{
		Flash_Read(addr,pBuf,len);
	}
}

#else
void SpiNand_ReadToCatch(uint32 addr)
{
	uint32 Block, Page, Temp;

	Block = addr/(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE);
	Page = (addr%(NAND_FLASH_BLOCK_PAGENUM*NAND_FLASH_PAGE_SIZE))/NAND_FLASH_PAGE_SIZE;	
	Temp = (Block<<6) | Page;

	Select_Flash_CS();				    
	Flash_SpiReadWrite(NAND_PAGEREADTOCATCH);	    	 
	Flash_SpiReadWrite((Temp>>16)&0xFF);
	Flash_SpiReadWrite((Temp>>8)&0xFF);
	Flash_SpiReadWrite((Temp)&0xFF);	
	Release_Flash_CS();	

	WaitForStatusRegister(SPINAND_IS_BUSY);
	PRINTF("**************read to catch done****************\r\n");
}

void SpiNand_ReadFromCatch (uint8 *pBuffer, uint16 offset, uint16 length)
{	
	uint16 i ,len;
	len = length;
	PRINTF("length = %d     ",length);	
	Select_Flash_CS();			    
	Flash_SpiReadWrite(NAND_READFROMCATCH);	    	 
	Flash_SpiReadWrite((offset>>8)&0xFF);
	Flash_SpiReadWrite((offset)&0xFF);
	Flash_SpiReadWrite(0xFF); 		  			/*need a dummy byte in read command	*/
	while (length--) 
	{
		*pBuffer = Flash_SpiReadWrite(0xff);
		pBuffer++;
	}
	Release_Flash_CS();

	for(i=0; i<len; i++){
		PRINTF("   data%d = %d   ",i , *pBuffer++);
	}
	PRINTF("******read from catch done********\r\n");
}


void SpiFlash_PageRead(uint32 addr,uint8*pBuf , uint16 len)
{
	uint16 offset;
	offset = addr%NAND_FLASH_PAGE_SIZE;

	SpiNand_ReadToCatch(addr);	
	SpiNand_ReadFromCatch(pBuf, offset, len);
}


void SpiFlash_Read( uint32 addr,uint8*pBuf , uint16 len)
{
	uint16 NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;

	Addr = addr%NAND_FLASH_PAGE_SIZE;				/*	ȷ����ַ�ڵ�ҳ��λ��*/
	count = NAND_FLASH_CACHE_SIZE - Addr;				/*	ȷ����ַ�ڵ�ҳʣ��ɶ�ȡ����*/
	NumOfPage =  len/NAND_FLASH_CACHE_SIZE;			/*	ȷ��Ҫ��ȡ������Ҫ������ҳ*/
	NumOfSingle = len%NAND_FLASH_CACHE_SIZE;		/*	ȷ��Ҫ��ȡ���ݳ�ȥ��ҳ��ʣ���ֽ���*/

	PRINTF("Addr  = %d  \r\n",Addr);
	PRINTF("count  = %d  \r\n",count);
	PRINTF("NumOfPage  = %d  \r\n",NumOfPage);
	PRINTF("NumOfSingle  = %d  \r\n",NumOfSingle);
	if (Addr == 0) 									/* ��ȡ�ĵ�ַ��ҳ����*/
	{
		if (NumOfPage == 0)							/* ��ȡ������С��һҳ*/
		{
			SpiFlash_PageRead(addr, pBuf, len);
		}
		else 										/* ��ȡ����������һҳ*/
		{
			while (NumOfPage--)						/* ��ȡ��ҳ��*/
			{
				SpiFlash_PageRead(addr,pBuf, NAND_FLASH_CACHE_SIZE);
				addr +=  NAND_FLASH_PAGE_SIZE;
				pBuf += NAND_FLASH_CACHE_SIZE;
			}
			if(NumOfSingle != 0)
			{
				SpiFlash_PageRead(addr, pBuf,NumOfSingle);  	/* ��ȡʣ���*/
			}
		}
	}
	else 											/* ��ȡ�ĵ�ַ����ҳ����*/
	{
		if (NumOfPage == 0) 							/* ��ȡ������С��һҳ*/
		{
			if (NumOfSingle > count)					/* ��ȡ���������ڱ�ҳʣ���ֽ���*/
			{ 	
				temp = NumOfSingle - count;
				SpiFlash_PageRead(addr,pBuf, count);		/* �ȶ�ȡ��ҳ�ɶ�ȡ����*/
				addr +=  (count+128);
				pBuf += count;
				SpiFlash_PageRead(addr, pBuf, temp);		/* Ȼ���ȡ��һҳ��Ҫ��ȡ������*/
			}
			else
			{
				SpiFlash_PageRead(addr, pBuf,len);	 	/* ��ȡ��ҳ�ɶ�����*/
			}
		}
		else 											/* ��ȡ����������һҳ*/
		{
			len -= count;
			NumOfPage =  len / NAND_FLASH_CACHE_SIZE;
			NumOfSingle = len % NAND_FLASH_CACHE_SIZE;
			SpiFlash_PageRead(addr, pBuf, count);			/* �ȶ�ȡ��ҳʣ�࣬����Ͱ�ҳ���������ȡ*/	
			addr +=  (count+128);
			pBuf += count;
			
			while (NumOfPage--)
			{
				SpiFlash_PageRead(addr,pBuf, NAND_FLASH_CACHE_SIZE);
				addr +=  NAND_FLASH_PAGE_SIZE;
				pBuf += NAND_FLASH_CACHE_SIZE;
			}
			if (NumOfSingle != 0)
			{
				SpiFlash_PageRead(addr,pBuf,NumOfSingle);
			}
		}
	}
}

void SpiFlash_Read_TP_Firmware( uint32 addr,uint8*pBuf , uint16 len)
{
	if(SetFlash_Nordic())
	{
		SpiFlash_Read(addr, pBuf, len);	
		SetFlash_Freescal();
	}
	else
	{
		Flash_Read(addr,pBuf,len);
	}
}


#endif

#if 0
void SpiFlash_Init(void)
{
	SpiFlash_Enable_IO();
	FORCE_NORDIC_FLASH_FLAG =true;
	UnlockGlobalBlockProtection();
	SpiFlash_ReadJedecID();
}
#else
void SpiFlash_Init(void)
{
	SpiFlash_Enable_IO();
	FORCE_NORDIC_FLASH_FLAG =true;
	UnlockGlobalBlockProtection();
	SpiFlash_ReadJedecID();
}

#endif






